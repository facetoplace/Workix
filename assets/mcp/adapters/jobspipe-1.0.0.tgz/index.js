// src/store.ts
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/jobspipe.ts
function jobspipeConfigured() {
  return Boolean(process.env.JOBSPIPE_API_KEY?.trim());
}
async function fetchJobsPipeJobs(opts) {
  const key = process.env.JOBSPIPE_API_KEY?.trim();
  if (!key) {
    return { jobs: [], error: "jobspipe: JOBSPIPE_API_KEY missing (optional)" };
  }
  const titles = opts?.titles?.length ? opts.titles : (process.env.JOBSPIPE_TITLES || "Software Engineer").split(",").map((s) => s.trim()).filter(Boolean);
  const body = {
    job_title_or: titles,
    limit: Math.min(Math.max(opts?.limit ?? 50, 1), 100)
  };
  if (opts?.keywords?.length) body.description_or = opts.keywords;
  const countries = opts?.countries?.length ? opts.countries : (process.env.JOBSPIPE_COUNTRIES || "").split(",").map((s) => s.trim()).filter(Boolean);
  if (countries.length) body.job_country_code_or = countries;
  const remote = opts?.remoteOnly ?? process.env.JOBSPIPE_REMOTE_ONLY !== "0";
  if (remote) body.remote = true;
  const maxAge = opts?.maxAgeDays ?? Number(process.env.JOBSPIPE_MAX_AGE_DAYS || 14);
  if (Number.isFinite(maxAge) && maxAge > 0) {
    body.posted_at_max_age_days = maxAge;
  }
  let data;
  try {
    const res = await fetch("https://api.jobspipe.dev/v1/jobs/search", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
      },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const detail = res.status === 429 ? " (monthly quota?)" : "";
      return { jobs: [], error: `JobsPipe HTTP ${res.status}${detail}` };
    }
    data = await res.json();
  } catch (e) {
    return {
      jobs: [],
      error: `jobspipe: ${e instanceof Error ? e.message : String(e)}`
    };
  }
  const jobs = [];
  for (const j of data.data || []) {
    const link = j.url || j.source_url;
    const title = j.job_title || j.normalized_title;
    if (!title || !link) continue;
    const cur = j.salary_currency || "USD";
    const budget = j.salary_string || (j.min_annual_salary && j.max_annual_salary ? `${j.min_annual_salary}\u2013${j.max_annual_salary} ${cur}/yr` : void 0);
    jobs.push({
      id: jobId("jobspipe", j.id || link),
      platform: "jobspipe",
      kind: "job",
      title: `${title}${j.company ? ` @ ${j.company}` : ""}`,
      description: (j.description || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4e3),
      link,
      date: j.date_posted ? new Date(j.date_posted).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
      budget,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: {
        location: j.location,
        country: j.country,
        remote: j.remote,
        work_arrangement: j.work_arrangement,
        // The same role on LinkedIn and on the company's Greenhouse board comes
        // back as two rows with two ids — keep the provenance for dedup upstream.
        sources: j.sources?.map((s) => s.name).filter(Boolean)
      }
    });
  }
  return { jobs, totalCount: data.metadata?.total };
}

// src/module-entries/jobspipe.ts
var meta = {
  id: "jobspipe",
  version: "1.0.0",
  platforms: ["jobspipe"],
  envKeys: [
    "JOBSPIPE_API_KEY",
    "JOBSPIPE_TITLES",
    "JOBSPIPE_COUNTRIES",
    "JOBSPIPE_REMOTE_ONLY",
    "JOBSPIPE_MAX_AGE_DAYS"
  ]
};
function configured() {
  return jobspipeConfigured();
}
async function fetchJobs(_ctx, opts) {
  return fetchJobsPipeJobs({
    titles: Array.isArray(opts?.titles) ? opts.titles : void 0,
    keywords: Array.isArray(opts?.keywords) ? opts.keywords : void 0,
    limit: typeof opts?.limit === "number" ? opts.limit : void 0
  });
}
export {
  configured,
  fetchJobs,
  meta
};
