// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}

// src/adapters/dstore.ts
var DSTORE_DOCS = {
  api: "https://dstore.one/api.txt",
  llms: "https://dstore.one/llms.txt",
  llm_alias: "https://dstore.one/llm.txt",
  agent: "https://dstore.one/agent",
  storefront: "https://dstore.one",
  addBase: "https://db.dstore.one"
};
function normalizeProductUrl(raw) {
  let u = String(raw || "").trim();
  if (!u) return { error: "url required" };
  if (!/^https?:\/\//i.test(u)) u = `https://${u}`;
  try {
    const parsed = new URL(u);
    if (!parsed.hostname) return { error: "invalid_url" };
    return parsed.toString();
  } catch {
    return { error: "invalid_url" };
  }
}
function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}
async function dstorePublish(args) {
  const url = normalizeProductUrl(args.url);
  if (typeof url !== "string") return { ok: false, ...url, docs: DSTORE_DOCS };
  const addUrl = `${DSTORE_DOCS.addBase}/?add=${encodeURIComponent(url)}`;
  const res = await fetchText(addUrl, {
    proxy: false,
    timeoutMs: 25e3,
    headers: {
      Accept: "application/json",
      "User-Agent": "Workix-MCP/0.3 (+https://workix.co; dstore publisher)"
    }
  });
  const body = parseJson(res.text);
  if (!res.ok) {
    return {
      ok: false,
      httpStatus: res.status,
      error: body?.error || res.error || `HTTP ${res.status}`,
      retry_after: body?.retry_after,
      body,
      docs: DSTORE_DOCS,
      tip: "Rate limit ~20 adds/IP/hour. Prefer reusing sid; do not re-add URL variants while polling."
    };
  }
  const sid = body?.sid;
  const status = body?.status;
  return {
    ok: true,
    status,
    sid,
    id: body?.id,
    productUrl: url,
    pageUrl: sid != null ? `${DSTORE_DOCS.storefront}/${sid}` : void 0,
    jsonUrl: sid != null ? `${DSTORE_DOCS.storefront}/${sid}.json` : void 0,
    note: status === "new" ? "Card created; enrichment may take 30\u2013120s. Poll workix_dstore_get until title/icon ready." : status === "exist" ? "Already in catalog \u2014 reuse sid, do not create duplicates via URL variants." : "Found; refresh scheduled. Poll JSON until enrichment settles.",
    docs: DSTORE_DOCS,
    body
  };
}
async function dstoreGetCard(args) {
  let sid = args.sid != null ? String(args.sid).trim() : "";
  if (!sid && args.url) {
    const m = String(args.url).match(
      /dstore\.one\/(?:list\/)?(\d+)(?:\.json)?/i
    );
    if (m) sid = m[1];
    else {
      const bare = String(args.url).replace(/\.json$/i, "").trim();
      if (/^\d+$/.test(bare)) sid = bare;
    }
  }
  if (!sid || !/^\d+$/.test(sid)) {
    return {
      ok: false,
      error: "Need numeric sid or dstore.one/{sid} URL",
      docs: DSTORE_DOCS
    };
  }
  const jsonUrl = `${DSTORE_DOCS.storefront}/${sid}.json`;
  const res = await fetchText(jsonUrl, {
    proxy: false,
    timeoutMs: 2e4,
    headers: {
      Accept: "application/json",
      "User-Agent": "Workix-MCP/0.3 (+https://workix.co; dstore reader)"
    }
  });
  const body = parseJson(res.text);
  if (!res.ok) {
    return {
      ok: false,
      httpStatus: res.status,
      sid,
      error: body?.error || res.error || `HTTP ${res.status}`,
      body,
      docs: DSTORE_DOCS
    };
  }
  const title = body?.title;
  const icon = body?.icon;
  const ready = Boolean(title) && Boolean(icon);
  return {
    ok: true,
    sid: body?.sid ?? Number(sid),
    ready,
    pageUrl: `${DSTORE_DOCS.storefront}/${sid}`,
    jsonUrl,
    card: body,
    tip: ready ? "Card enriched \u2014 open pageUrl for human check." : "Still enriching \u2014 poll again in 5\u201310s (up to ~3 min). Do not re-call publish for the same URL.",
    docs: DSTORE_DOCS
  };
}

// src/module-entries/dstore.ts
var meta = {
  id: "dstore",
  version: "1.0.0",
  platforms: ["dstore"]
};
async function fetchJobs(_ctx) {
  return {
    jobs: [],
    error: "optional: dStore is an app catalog (PWA/websites), not gigs. Use workix_dstore_publish / workix_dstore_get."
  };
}
export {
  DSTORE_DOCS,
  fetchJobs,
  dstoreGetCard as getCard,
  meta,
  dstorePublish as publish
};
