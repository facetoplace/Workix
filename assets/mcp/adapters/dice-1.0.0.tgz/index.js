// src/mcpClient.ts
var PROTOCOL_VERSION = "2025-06-18";
var CLIENT_INFO = { name: "workix-mcp", version: "0.3.2" };
function unwrap(body) {
  const trimmed = body.trim();
  if (!trimmed) throw new Error("empty response");
  if (trimmed.startsWith("{")) return JSON.parse(trimmed);
  const frames = trimmed.split(/\n\n+/).map(
    (chunk) => chunk.split("\n").filter((l) => l.startsWith("data:")).map((l) => l.slice(5).trim()).join("")
  ).filter((d) => d.startsWith("{"));
  if (!frames.length) throw new Error("no JSON frame in SSE response");
  return JSON.parse(frames[frames.length - 1]);
}
async function callMcpTool(opts) {
  const timeoutMs = opts.timeoutMs ?? 45e3;
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json, text/event-stream"
  };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const post = async (payload) => fetch(opts.url, {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
    signal: controller.signal
  });
  try {
    const init = await post({
      jsonrpc: "2.0",
      id: 1,
      method: "initialize",
      params: {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: {},
        clientInfo: CLIENT_INFO
      }
    });
    if (!init.ok) {
      return { error: `initialize HTTP ${init.status}` };
    }
    const session = init.headers.get("mcp-session-id");
    if (session) headers["mcp-session-id"] = session;
    await init.text();
    await post({ jsonrpc: "2.0", method: "notifications/initialized" }).catch(
      () => void 0
    );
    const res = await post({
      jsonrpc: "2.0",
      id: 2,
      method: "tools/call",
      params: { name: opts.tool, arguments: opts.args }
    });
    const body = await res.text();
    if (!res.ok) {
      return { error: `${opts.tool} HTTP ${res.status}: ${body.slice(0, 200)}` };
    }
    const env = unwrap(body);
    if (env.error) {
      return {
        error: `${opts.tool}: ${env.error.message || `rpc ${env.error.code}`}`
      };
    }
    const text = env.result?.content?.find((c) => c.text)?.text;
    let data;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
      }
    }
    return {
      data,
      text,
      structured: env.result?.structuredContent,
      isError: env.result?.isError
    };
  } catch (e) {
    if (e instanceof Error && e.name === "AbortError") {
      return { error: `${opts.tool}: timed out after ${timeoutMs}ms` };
    }
    return { error: e instanceof Error ? e.message : String(e) };
  } finally {
    clearTimeout(timer);
  }
}

// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/dice.ts
var MCP_URL = "https://mcp.dice.com/mcp";
function postedWindow(hours) {
  if (!hours) return void 0;
  if (hours <= 24) return "ONE";
  if (hours <= 72) return "THREE";
  if (hours <= 168) return "SEVEN";
  return void 0;
}
async function fetchDiceJobs(opts) {
  const keyword = (opts?.keywords || []).filter(Boolean).join(" ").trim() || process.env.DICE_KEYWORD?.trim() || "developer";
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 100);
  const sponsor = opts?.willingToSponsor ?? (process.env.DICE_SPONSOR_ONLY === "1" || void 0);
  const remoteOnly = opts?.remoteOnly ?? (process.env.DICE_REMOTE_ONLY === "1" || void 0);
  const args = {
    keyword,
    jobs_per_page: limit,
    page_number: 1
  };
  const posted = postedWindow(opts?.hours);
  if (posted) args.posted_date = posted;
  if (opts?.location) args.location = opts.location;
  if (sponsor) args.willing_to_sponsor = true;
  if (remoteOnly) args.workplace_types = ["Remote"];
  const res = await callMcpTool({ url: MCP_URL, tool: "search_jobs", args });
  if (res.error) return { jobs: [], error: `dice: ${res.error}` };
  if (res.isError) {
    return { jobs: [], error: `dice: ${(res.text || "rejected").slice(0, 300)}` };
  }
  const payload = res.structured ?? res.data;
  const rows = payload?.data;
  if (!Array.isArray(rows)) {
    return { jobs: [], error: "dice: unexpected response shape" };
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const jobs = [];
  for (const row of rows) {
    const link = row.detailsPageUrl;
    if (!link || !row.title) continue;
    jobs.push({
      id: jobId("dice", row.guid || row.id || link),
      platform: "dice",
      kind: "job",
      title: row.title,
      description: (row.summary || "").replace(/\s+/g, " ").trim().slice(0, 4e3),
      link,
      date: row.postedDate || row.modifiedDate || now,
      budget: row.salary?.trim() || void 0,
      fetchedAt: now,
      raw: {
        company: row.companyName,
        location: row.jobLocation?.displayName,
        employmentType: row.employmentType,
        employerType: row.employerType,
        workplaceTypes: row.workplaceTypes,
        isRemote: row.isRemote,
        // Dice is the only source in the set that publishes this.
        willingToSponsor: row.willingToSponsor,
        easyApply: row.easyApply
      }
    });
  }
  return { jobs, totalCount: payload?.metadata?.total };
}

// src/module-entries/dice.ts
var meta = {
  id: "dice",
  version: "1.0.0",
  platforms: ["dice"],
  envKeys: ["DICE_KEYWORD", "DICE_REMOTE_ONLY", "DICE_SPONSOR_ONLY"]
};
async function fetchJobs(_ctx, opts) {
  return fetchDiceJobs({
    keywords: Array.isArray(opts?.keywords) ? opts.keywords.filter((k) => typeof k === "string") : void 0,
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    hours: typeof opts?.hours === "number" ? opts.hours : void 0,
    location: typeof opts?.location === "string" ? opts.location : void 0,
    willingToSponsor: typeof opts?.willing_to_sponsor === "boolean" ? opts.willing_to_sponsor : void 0
  });
}
export {
  fetchJobs,
  meta
};
