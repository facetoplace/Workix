// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/cookies.ts
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { join as join2 } from "node:path";

// src/store.ts
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function resolveDataDir() {
  if (process.env.WORKIX_MCP_DATA?.trim()) {
    return process.env.WORKIX_MCP_DATA.trim();
  }
  return join(ROOT, "data");
}
function storePath() {
  return join(resolveDataDir(), "store.json");
}
function empty() {
  return {
    jobs: {},
    drafts: [],
    shownDigestIds: [],
    outreach: [],
    checkpoints: [],
    hubShares: []
  };
}
function ensure() {
  const dir = resolveDataDir();
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const path = storePath();
  if (!existsSync(path)) {
    writeFileSync(path, JSON.stringify(empty(), null, 2), "utf8");
  }
}
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}
function dataDir() {
  ensure();
  return resolveDataDir();
}

// src/cookies.ts
function cookiesDir() {
  const dir = join2(dataDir(), "cookies");
  if (!existsSync2(dir)) mkdirSync2(dir, { recursive: true });
  return dir;
}
function jarPath(jar) {
  return join2(cookiesDir(), `${jar}.json`);
}
function loadCookies(jar) {
  const file = jarPath(jar);
  if (!existsSync2(file)) return [];
  try {
    const parsed = JSON.parse(readFileSync2(file, "utf8"));
    return Array.isArray(parsed.cookies) ? parsed.cookies : [];
  } catch {
    return [];
  }
}
function saveCookies(jar, cookies) {
  const body = {
    jar,
    updated: (/* @__PURE__ */ new Date()).toISOString(),
    cookies
  };
  writeFileSync2(jarPath(jar), JSON.stringify(body, null, 2), "utf8");
}
function domainMatches(cookieDomain, host) {
  const d = cookieDomain.replace(/^\./, "").toLowerCase();
  const h = host.toLowerCase();
  return h === d || h.endsWith(`.${d}`);
}
function pathMatches(cookiePath, urlPath) {
  const c = cookiePath || "/";
  if (c === "/") return true;
  if (urlPath === c) return true;
  return urlPath.startsWith(c.endsWith("/") ? c : `${c}/`);
}
function notExpired(c, nowSec) {
  if (c.expires == null || c.expires <= 0) return true;
  return c.expires > nowSec;
}
function cookieHeaderFor(jar, url) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return void 0;
  }
  const nowSec = Math.floor(Date.now() / 1e3);
  const secure = u.protocol === "https:";
  const matched = loadCookies(jar).filter(
    (c) => domainMatches(c.domain, u.hostname) && pathMatches(c.path, u.pathname) && notExpired(c, nowSec) && (secure || !c.secure)
  );
  if (!matched.length) return void 0;
  matched.sort((a, b) => (b.path || "/").length - (a.path || "/").length);
  const seen = /* @__PURE__ */ new Set();
  const parts = [];
  for (const c of matched) {
    if (seen.has(c.name)) continue;
    seen.add(c.name);
    parts.push(`${c.name}=${c.value}`);
  }
  return parts.join("; ");
}
function parseSetCookie(line, url) {
  const [pair, ...attrs] = line.split(";");
  const eq = pair.indexOf("=");
  if (eq < 1) return void 0;
  let host;
  let defaultPath = "/";
  try {
    const u = new URL(url);
    host = u.hostname;
    defaultPath = u.pathname.replace(/\/[^/]*$/, "") || "/";
  } catch {
    return void 0;
  }
  const cookie = {
    name: pair.slice(0, eq).trim(),
    value: pair.slice(eq + 1).trim(),
    domain: host,
    path: defaultPath
  };
  for (const raw of attrs) {
    const [k, ...rest] = raw.split("=");
    const key = k.trim().toLowerCase();
    const val = rest.join("=").trim();
    if (key === "domain" && val) cookie.domain = val.replace(/^\./, "");
    else if (key === "path" && val) cookie.path = val;
    else if (key === "secure") cookie.secure = true;
    else if (key === "httponly") cookie.httpOnly = true;
    else if (key === "max-age" && val) {
      const secs = Number(val);
      if (Number.isFinite(secs)) {
        cookie.expires = Math.floor(Date.now() / 1e3) + secs;
      }
    } else if (key === "expires" && val && cookie.expires == null) {
      const t = Date.parse(val);
      if (!Number.isNaN(t)) cookie.expires = Math.floor(t / 1e3);
    }
  }
  return cookie;
}
function mergeSetCookie(jar, url, setCookie) {
  if (!setCookie) return;
  const lines = Array.isArray(setCookie) ? setCookie : [setCookie];
  if (!lines.length) return;
  const existing = loadCookies(jar);
  let changed = false;
  for (const line of lines) {
    const parsed = parseSetCookie(line, url);
    if (!parsed) continue;
    const idx = existing.findIndex(
      (c) => c.name === parsed.name && c.domain.replace(/^\./, "") === parsed.domain && c.path === parsed.path
    );
    const deleted = !parsed.value && parsed.expires != null && parsed.expires <= Math.floor(Date.now() / 1e3);
    if (deleted) {
      if (idx >= 0) {
        existing.splice(idx, 1);
        changed = true;
      }
      continue;
    }
    if (idx >= 0) existing[idx] = parsed;
    else existing.push(parsed);
    changed = true;
  }
  if (changed) saveCookies(jar, existing);
}

// src/env.ts
import { config } from "dotenv";
import { existsSync as existsSync3 } from "node:fs";
import { dirname as dirname2, join as join3 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join3(dirname2(fileURLToPath2(import.meta.url)), "..");
var REPO_ROOT = join3(ROOT2, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join3(ROOT2, ".env");
  const rootEnv = join3(REPO_ROOT, ".env");
  if (existsSync3(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync3(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  const directFallback = opts?.directFallback !== false;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs, cookieJar: opts?.cookieJar });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs,
      cookieJar: opts.cookieJar
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  if (directFallback) tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs,
      cookieJar: opts?.cookieJar
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const jarHeader = opts.cookieJar ? cookieHeaderFor(opts.cookieJar, url) : void 0;
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...jarHeader ? { Cookie: jarHeader } : {},
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (opts.cookieJar) {
            mergeSetCookie(opts.cookieJar, url, res.headers["set-cookie"]);
          }
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}
async function fetchJson(url, opts) {
  const res = await fetchText(url, opts);
  if (!res.ok) {
    return { error: res.error, status: res.status, ms: res.ms };
  }
  try {
    return { data: JSON.parse(res.text), status: res.status, ms: res.ms };
  } catch (e) {
    return {
      error: e instanceof Error ? e.message : "JSON parse error",
      status: res.status,
      ms: res.ms
    };
  }
}

// src/adapters/aidevboard.ts
async function fetchAidevboardJobs(opts) {
  const maxPages = Math.min(Math.max(opts?.pages ?? 2, 1), 5);
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 50);
  const q = opts?.q?.trim() || process.env.AIDEV_Q?.trim() || "";
  const tags = opts?.tags?.trim() || process.env.AIDEV_TAGS?.trim() || "";
  const workplace = opts?.workplace?.trim() || process.env.AIDEV_WORKPLACE?.trim() || "remote";
  const apiKey = process.env.AIDEV_API_KEY?.trim() || "";
  const postedWithin = Number(process.env.AIDEV_POSTED_WITHIN_DAYS || "30") || 30;
  const headers = {
    Accept: "application/json",
    "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
  };
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
  const jobs = [];
  let lastError = "";
  for (let page = 1; page <= maxPages; page++) {
    const qs = new URLSearchParams({
      page: String(page),
      limit: String(limit),
      posted_within_days: String(Math.min(Math.max(postedWithin, 1), 90))
    });
    if (workplace && workplace !== "all") qs.set("workplace", workplace);
    if (q) qs.set("q", q);
    if (tags) qs.set("tags", tags);
    const url = `https://aidevboard.com/api/v1/jobs?${qs}`;
    const { data, error, status } = await fetchJson(url, {
      headers,
      proxy: false
    });
    if (error || !data?.jobs || !Array.isArray(data.jobs)) {
      lastError = error || `AI Dev Jobs HTTP ${status}`;
      break;
    }
    for (const row of data.jobs) {
      const link = row.url || (row.id ? `https://aidevboard.com/job/${row.id}` : "");
      if (!row.title || !link) continue;
      const company = row.company_name ? ` @ ${row.company_name}` : "";
      jobs.push({
        id: jobId("aidevboard", String(row.id || link)),
        platform: "aidevboard",
        kind: "job",
        title: `${row.title}${company}`,
        description: (row.description || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4e3),
        link,
        date: row.published_at ? new Date(row.published_at).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
        fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
        raw: {
          workplace: row.workplace,
          location: row.location,
          job_type: row.job_type,
          experience_level: row.experience_level,
          salary_min: row.salary_min,
          salary_max: row.salary_max,
          tags: row.tags,
          apply_url: row.apply_url
        }
      });
    }
    if (!data.has_next || data.jobs.length === 0) break;
  }
  if (!jobs.length && lastError) return { jobs: [], error: lastError };
  return { jobs, error: lastError || void 0 };
}

// src/module-entries/aidevboard.ts
var meta = {
  id: "aidevboard",
  version: "1.0.0",
  platforms: ["aidevboard"],
  envKeys: ["AIDEV_API_KEY", "AIDEV_Q", "AIDEV_TAGS", "AIDEV_WORKPLACE"]
};
async function fetchJobs(_ctx, opts) {
  return fetchAidevboardJobs({
    pages: typeof opts?.pages === "number" ? opts.pages : void 0,
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    q: typeof opts?.q === "string" ? opts.q : void 0,
    tags: typeof opts?.tags === "string" ? opts.tags : void 0,
    workplace: typeof opts?.workplace === "string" ? opts.workplace : void 0
  });
}
export {
  fetchJobs,
  meta
};
