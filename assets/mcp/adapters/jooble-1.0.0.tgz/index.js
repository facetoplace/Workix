// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/jooble.ts
function joobleConfigured() {
  return Boolean(process.env.JOOBLE_API_KEY?.trim());
}
async function fetchJoobleJobs(opts) {
  const key = process.env.JOOBLE_API_KEY?.trim();
  if (!key) {
    return { jobs: [], error: "jooble: JOOBLE_API_KEY missing (optional)" };
  }
  const keywords = opts?.keywords?.trim() || process.env.JOOBLE_KEYWORDS?.trim() || "developer";
  const location = opts?.location?.trim() || process.env.JOOBLE_LOCATION?.trim() || "";
  let data;
  try {
    const res = await fetch(`https://jooble.org/api/${encodeURIComponent(key)}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
      },
      body: JSON.stringify({
        keywords,
        location,
        page: String(opts?.page ?? 1)
      })
    });
    if (!res.ok) return { jobs: [], error: `Jooble HTTP ${res.status}` };
    data = await res.json();
  } catch (e) {
    return {
      jobs: [],
      error: `jooble: ${e instanceof Error ? e.message : String(e)}`
    };
  }
  const jobs = [];
  for (const j of data.jobs || []) {
    if (!j.title || !j.link) continue;
    jobs.push({
      id: jobId("jooble", String(j.id || j.link)),
      platform: "jooble",
      kind: "job",
      title: `${j.title}${j.company ? ` @ ${j.company}` : ""}`,
      description: (j.snippet || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4e3),
      link: j.link,
      date: j.updated ? new Date(j.updated).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
      budget: j.salary || void 0,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: { location: j.location, source: j.source, type: j.type }
    });
  }
  return { jobs, totalCount: data.totalCount };
}

// src/module-entries/jooble.ts
var meta = {
  id: "jooble",
  version: "1.0.0",
  platforms: ["jooble"],
  envKeys: ["JOOBLE_API_KEY", "JOOBLE_KEYWORDS", "JOOBLE_LOCATION"]
};
function configured() {
  return joobleConfigured();
}
async function fetchJobs(_ctx, opts) {
  const kw = Array.isArray(opts?.keywords) ? opts.keywords : [];
  return fetchJoobleJobs({
    keywords: typeof opts?.query === "string" ? opts.query : kw.join(" ") || void 0
  });
}
export {
  configured,
  fetchJobs,
  meta
};
