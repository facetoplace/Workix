// src/adapters/jobspy.ts
import { spawn } from "node:child_process";

// src/store.ts
import { createHash } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/jobspy.ts
var SITE_BY_PLATFORM = {
  indeed: "indeed",
  glassdoor: "glassdoor",
  ziprecruiter: "zip_recruiter",
  naukri: "naukri",
  bdjobs: "bdjobs"
};
var JOBSPY_PLATFORMS = Object.keys(SITE_BY_PLATFORM);
var INSTALL_HINT = "JobSpy is not installed. It is optional: pip install -U python-jobspy \u2014 needs Python 3.10\u20133.12 (it pins numpy 1.26.3, which does not build on 3.13). On 3.13, make a venv with an older interpreter and point PYTHON_BIN at it.";
var STALE_HINT = "This usually means the credentials baked into your jobspy release were rotated by the board. Upgrade to pick up the new ones: pip install -U python-jobspy";
var STALE_SIGNALS = /\b(401|403|unauthorized|forbidden|invalid[_ -]?api[_ -]?key|authentication)\b/i;
var UPSTREAM_BUG = /\b(TypeError|AttributeError|KeyError|ImportError|NameError)\b/;
var BUG_HINT = "That is an exception inside jobspy itself, not a block \u2014 upgrading or retrying will not help. Check its issue tracker: https://github.com/speedyapply/JobSpy/issues";
var BLOCKED_HINT = "The board refused the request. Usually an IP-level block (Cloudflare) or a rate limit rather than anything wrong on your side \u2014 try again later, from a different IP, or pass proxies.";
function diagnose(stderr) {
  if (UPSTREAM_BUG.test(stderr)) return ` ${BUG_HINT}`;
  if (/\b(401|invalid[_ -]?api[_ -]?key|authentication)\b/i.test(stderr)) return ` ${STALE_HINT}`;
  if (STALE_SIGNALS.test(stderr)) return ` ${BLOCKED_HINT}`;
  if (/\b(timeout|timed out|ReadTimeout|Max retries exceeded)\b/i.test(stderr)) {
    return " The board did not respond \u2014 it may be unreachable or geo-blocked from here.";
  }
  return "";
}
var VERSION_PROBE = [
  "import jobspy",
  "try:",
  "    from importlib.metadata import version as _v",
  "    print('ok', _v('python-jobspy'))",
  "except Exception:",
  "    print('ok', getattr(jobspy, '__version__', 'unknown'))"
].join("\n");
function pythonCandidates(env) {
  return [env.PYTHON_BIN, "python3", "python"].filter(Boolean);
}
function runPython(bin, script, timeoutMs) {
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(bin, ["-c", script], { stdio: ["ignore", "pipe", "pipe"] });
    } catch {
      resolve({ ok: false, stdout: "", stderr: `cannot spawn ${bin}` });
      return;
    }
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child.kill();
      resolve({ ok: false, stdout, stderr: `${bin}: timed out` });
    }, timeoutMs);
    child.stdout.on("data", (c) => stdout += c.toString());
    child.stderr.on("data", (c) => stderr += c.toString());
    child.on("error", (e) => {
      clearTimeout(timer);
      resolve({ ok: false, stdout, stderr: e.message });
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ ok: code === 0, stdout, stderr });
    });
  });
}
var cachedBin;
var cachedVersion;
async function resolvePython(env) {
  if (cachedBin !== void 0) return cachedBin;
  for (const bin of pythonCandidates(env)) {
    const r = await runPython(bin, VERSION_PROBE, 2e4);
    if (r.ok && r.stdout.startsWith("ok")) {
      cachedBin = bin;
      cachedVersion = r.stdout.trim().split(/\s+/)[1] || "unknown";
      return bin;
    }
  }
  cachedBin = null;
  return null;
}
async function jobspyAvailable(env) {
  return await resolvePython(env) !== null;
}
function money(row) {
  const { min_amount: lo, max_amount: hi } = row;
  if (lo == null && hi == null) return void 0;
  const cur = row.currency || "USD";
  const per = row.interval ? `/${row.interval}` : "";
  const range = lo != null && hi != null ? `${lo}\u2013${hi}` : String(lo ?? hi);
  return `${range} ${cur}${per}`;
}
async function fetchJobSpyJobs(opts) {
  const site = SITE_BY_PLATFORM[opts.platform];
  if (!site) return { jobs: [], error: `jobspy: unknown platform ${opts.platform}` };
  const bin = await resolvePython(opts.env);
  if (!bin) return { jobs: [], error: INSTALL_HINT };
  const params = {
    site_name: [site],
    search_term: opts.what || "",
    results_wanted: Math.min(Math.max(opts.limit ?? 50, 1), 200),
    hours_old: opts.hours,
    location: opts.location,
    proxies: opts.proxies?.length ? opts.proxies : void 0
  };
  const script = [
    "import json,sys",
    "from jobspy import scrape_jobs",
    `p = json.loads(sys.stdin.read() or ${JSON.stringify(JSON.stringify(params))})`,
    "p = {k: v for k, v in p.items() if v is not None}",
    "df = scrape_jobs(**p)",
    "sys.stdout.write(df.to_json(orient='records', date_format='iso') if df is not None and len(df) else '[]')"
  ].join("\n");
  const res = await runPython(bin, script, 18e4);
  if (!res.ok) {
    const tail = res.stderr.trim().split("\n").slice(-3).join(" ").slice(0, 400);
    return {
      jobs: [],
      error: `jobspy ${opts.platform} (v${cachedVersion || "?"}): ${tail || "failed"}.` + diagnose(res.stderr)
    };
  }
  let rows;
  try {
    rows = JSON.parse(res.stdout.trim() || "[]");
  } catch {
    return { jobs: [], error: `jobspy ${opts.platform}: unparseable output` };
  }
  if (!rows.length) {
    const logged = res.stderr.split("\n").filter((l) => /ERROR/.test(l) && /JobSpy/i.test(l)).map((l) => l.replace(/^.*?JobSpy:?/i, "").trim()).filter(Boolean);
    if (logged.length) {
      return {
        jobs: [],
        error: `jobspy ${opts.platform} (v${cachedVersion || "?"}) returned nothing and logged: ${logged.slice(0, 3).join(" | ").slice(0, 300)}.` + diagnose(res.stderr)
      };
    }
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const jobs = [];
  for (const row of rows) {
    const link = row.job_url;
    if (!link || !row.title) continue;
    let date = now;
    if (row.date_posted) {
      const t = Date.parse(row.date_posted);
      if (!Number.isNaN(t)) date = new Date(t).toISOString();
    }
    jobs.push({
      id: jobId(opts.platform, link),
      platform: opts.platform,
      kind: "job",
      title: `${row.title}${row.company ? " @ " + row.company : ""}`,
      description: (row.description || "").replace(/<[^>]+>/g, " ").slice(0, 4e3),
      link,
      date,
      budget: money(row),
      fetchedAt: now,
      raw: { location: row.location, is_remote: row.is_remote, via: "jobspy" }
    });
  }
  return { jobs };
}

// src/module-entries/jobspy.ts
var meta = {
  id: "jobspy",
  version: "1.0.3",
  platforms: ["indeed", "glassdoor", "ziprecruiter", "naukri", "bdjobs"],
  envKeys: ["PYTHON_BIN"]
};
if (meta.platforms.length !== JOBSPY_PLATFORMS.length || meta.platforms.some((p) => !JOBSPY_PLATFORMS.includes(p))) {
  throw new Error(
    `jobspy: meta.platforms [${meta.platforms}] out of sync with the adapter [${JOBSPY_PLATFORMS}]`
  );
}
async function configured() {
  return jobspyAvailable(process.env);
}
async function fetchJobs(ctx, opts) {
  const platform = typeof opts?.platform === "string" ? opts.platform : "indeed";
  return fetchJobSpyJobs({
    env: ctx.env,
    platform,
    what: typeof opts?.what === "string" ? opts.what : void 0,
    location: typeof opts?.location === "string" ? opts.location : void 0,
    hours: typeof opts?.hours === "number" ? opts.hours : void 0,
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    proxies: Array.isArray(opts?.proxies) ? opts.proxies.filter((p) => typeof p === "string") : void 0
  });
}
export {
  configured,
  fetchJobs,
  meta
};
