// src/adapters/jobspipe.ts
import { mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync } from "node:fs";
import { dirname as dirname2, join as join2 } from "node:path";

// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { existsSync, mkdirSync, readFileSync, renameSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function resolveDataDir() {
  const fromEnv = process.env.WORKIX_MCP_DATA?.trim();
  return fromEnv || join(ROOT, "data");
}
var handle = null;
var SCHEMA = `
CREATE TABLE IF NOT EXISTS jobs (
  id              TEXT PRIMARY KEY,
  platform        TEXT NOT NULL,
  kind            TEXT,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL DEFAULT '',
  link            TEXT NOT NULL,
  date            TEXT NOT NULL,
  budget          TEXT,
  raw             TEXT,
  fetched_at      TEXT NOT NULL,
  seen_at         TEXT NOT NULL,
  shown_in_digest INTEGER NOT NULL DEFAULT 0,
  hub_share       TEXT
);
CREATE INDEX IF NOT EXISTS jobs_platform ON jobs(platform);
CREATE INDEX IF NOT EXISTS jobs_date ON jobs(date DESC);
CREATE INDEX IF NOT EXISTS jobs_link ON jobs(link);
CREATE INDEX IF NOT EXISTS jobs_seen ON jobs(seen_at DESC);

CREATE TABLE IF NOT EXISTS shown_digest (
  id TEXT PRIMARY KEY,
  at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS drafts (
  rowid_alias INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id      TEXT NOT NULL,
  text        TEXT NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS drafts_job ON drafts(job_id, created_at DESC);

CREATE TABLE IF NOT EXISTS outreach (
  id      TEXT PRIMARY KEY,
  at      TEXT NOT NULL,
  status  TEXT NOT NULL,
  channel TEXT NOT NULL,
  contact TEXT NOT NULL,
  text    TEXT NOT NULL,
  project TEXT,
  url     TEXT,
  job_id  TEXT,
  note    TEXT
);
CREATE INDEX IF NOT EXISTS outreach_at ON outreach(at DESC);

CREATE TABLE IF NOT EXISTS checkpoints (
  id       TEXT PRIMARY KEY,
  at       TEXT NOT NULL,
  summary  TEXT NOT NULL,
  next     TEXT,
  surfaces TEXT,
  batch    TEXT,
  blocked  TEXT,
  note     TEXT
);
CREATE INDEX IF NOT EXISTS checkpoints_at ON checkpoints(at DESC);

CREATE TABLE IF NOT EXISTS hub_shares (
  id           TEXT PRIMARY KEY,
  at           TEXT NOT NULL,
  job_id       TEXT NOT NULL,
  platform     TEXT NOT NULL,
  title        TEXT NOT NULL,
  external_url TEXT NOT NULL,
  sid          TEXT NOT NULL,
  hub_url      TEXT NOT NULL,
  hub_id       TEXT,
  status       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS hub_shares_at ON hub_shares(at DESC);
CREATE INDEX IF NOT EXISTS hub_shares_job ON hub_shares(job_id);

CREATE TABLE IF NOT EXISTS fetch_cache (
  key        TEXT PRIMARY KEY,
  source     TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  items      INTEGER NOT NULL DEFAULT 0,
  payload    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS fetch_cache_source ON fetch_cache(source);
CREATE INDEX IF NOT EXISTS fetch_cache_expires ON fetch_cache(expires_at);

CREATE TABLE IF NOT EXISTS meta (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);
`;
function db() {
  const dir = resolveDataDir();
  if (handle && handle.dir === dir) return handle.db;
  if (handle) handle.db.close();
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const conn = new DatabaseSync(join(dir, "workix.db"));
  conn.exec("PRAGMA journal_mode = WAL");
  conn.exec("PRAGMA busy_timeout = 5000");
  conn.exec("PRAGMA foreign_keys = ON");
  conn.exec(SCHEMA);
  handle = { db: conn, dir };
  migrateStoreJson(conn, dir);
  return conn;
}
function nullable(v) {
  if (v === void 0 || v === null || v === "") return null;
  return typeof v === "string" ? v : JSON.stringify(v);
}
function migrateStoreJson(conn, dir) {
  const already = conn.prepare("SELECT v FROM meta WHERE k = 'migrated_store_json'").get();
  if (already) return;
  const legacy = join(dir, "store.json");
  if (!existsSync(legacy)) {
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run((/* @__PURE__ */ new Date()).toISOString());
    return;
  }
  let data;
  try {
    data = JSON.parse(readFileSync(legacy, "utf8"));
  } catch {
    return;
  }
  const jobs = Object.values(
    data.jobs || {}
  );
  const insJob = conn.prepare(
    `INSERT OR REPLACE INTO jobs
     (id, platform, kind, title, description, link, date, budget, raw, fetched_at, seen_at, shown_in_digest, hub_share)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShown = conn.prepare(
    "INSERT OR IGNORE INTO shown_digest (id, at) VALUES (?, ?)"
  );
  const insDraft = conn.prepare(
    "INSERT INTO drafts (job_id, text, created_at) VALUES (?, ?, ?)"
  );
  const insOutreach = conn.prepare(
    `INSERT OR REPLACE INTO outreach (id, at, status, channel, contact, text, project, url, job_id, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insCheckpoint = conn.prepare(
    `INSERT OR REPLACE INTO checkpoints (id, at, summary, next, surfaces, batch, blocked, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShare = conn.prepare(
    `INSERT OR REPLACE INTO hub_shares (id, at, job_id, platform, title, external_url, sid, hub_url, hub_id, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const now = (/* @__PURE__ */ new Date()).toISOString();
  conn.exec("BEGIN");
  try {
    for (const j of jobs) {
      if (!j?.id || !j?.title || !j?.link) continue;
      insJob.run(
        String(j.id),
        String(j.platform || "unknown"),
        nullable(j.kind),
        String(j.title),
        String(j.description || ""),
        String(j.link),
        String(j.date || now),
        nullable(j.budget),
        j.raw === void 0 ? null : JSON.stringify(j.raw),
        String(j.fetchedAt || now),
        String(j.seenAt || now),
        j.shownInDigest ? 1 : 0,
        j.hubShare ? JSON.stringify(j.hubShare) : null
      );
    }
    for (const id of data.shownDigestIds || []) {
      insShown.run(String(id), now);
    }
    for (const d of data.drafts || []) {
      if (!d?.jobId) continue;
      insDraft.run(String(d.jobId), String(d.text || ""), String(d.createdAt || now));
    }
    for (const o of data.outreach || []) {
      if (!o?.id) continue;
      insOutreach.run(
        String(o.id),
        String(o.at || now),
        String(o.status || "draft"),
        String(o.channel || ""),
        String(o.contact || ""),
        String(o.text || ""),
        nullable(o.project),
        nullable(o.url),
        nullable(o.jobId),
        nullable(o.note)
      );
    }
    for (const c of data.checkpoints || []) {
      if (!c?.id) continue;
      insCheckpoint.run(
        String(c.id),
        String(c.at || now),
        String(c.summary || ""),
        nullable(c.next),
        c.surfaces ? JSON.stringify(c.surfaces) : null,
        nullable(c.batch),
        c.blocked ? JSON.stringify(c.blocked) : null,
        nullable(c.note)
      );
    }
    for (const h of data.hubShares || []) {
      if (!h?.id) continue;
      insShare.run(
        String(h.id),
        String(h.at || now),
        String(h.jobId || ""),
        String(h.platform || ""),
        String(h.title || ""),
        String(h.externalUrl || ""),
        String(h.sid || ""),
        String(h.hubUrl || ""),
        nullable(h.hubId),
        String(h.status || "created")
      );
    }
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run(now);
    conn.exec("COMMIT");
  } catch (e) {
    conn.exec("ROLLBACK");
    throw e;
  }
  try {
    renameSync(legacy, `${legacy}.migrated`);
  } catch {
  }
  if (process.env.WORKIX_MCP_DEBUG) {
    console.error(`[workix] migrated ${jobs.length} jobs from store.json \u2192 workix.db`);
  }
}

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}
function dataDir() {
  db();
  return resolveDataDir();
}

// src/adapters/jobspipe.ts
var SEARCH_URL = "https://api.jobspipe.dev/v1/jobs/search";
var MIN_GAP_MS = 550;
var lastCallAt = 0;
async function pace() {
  const wait = MIN_GAP_MS - (Date.now() - lastCallAt);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCallAt = Date.now();
}
function jobspipeKey() {
  return process.env.JOBSPIPE_API_KEY?.trim() || process.env.JOBS_PIPE_KEY?.trim() || "";
}
function jobspipeConfigured() {
  return Boolean(jobspipeKey());
}
function ledgerPath() {
  return join2(dataDir(), "jobspipe-usage.json");
}
function currentMonth() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 7);
}
function readLedger() {
  const month = currentMonth();
  try {
    const raw = JSON.parse(readFileSync2(ledgerPath(), "utf8"));
    if (raw.month === month) return raw;
  } catch {
  }
  return { month, jobs: 0, calls: 0, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
}
function writeLedger(l) {
  try {
    mkdirSync2(dirname2(ledgerPath()), { recursive: true });
    writeFileSync(ledgerPath(), JSON.stringify(l, null, 2), "utf8");
  } catch {
  }
}
function monthlyBudget() {
  const n = Number(process.env.JOBSPIPE_MONTHLY_BUDGET || 1e3);
  return Number.isFinite(n) && n > 0 ? n : 1e3;
}
function jobspipeUsage() {
  const l = readLedger();
  const budget = monthlyBudget();
  return {
    month: l.month,
    jobs: l.jobs,
    calls: l.calls,
    budget,
    remaining: Math.max(0, budget - l.jobs),
    configured: jobspipeConfigured()
  };
}
function spend(jobs) {
  const l = readLedger();
  l.jobs += jobs;
  l.calls += 1;
  l.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  writeLedger(l);
}
function envList(name) {
  const raw = process.env[name]?.trim();
  if (!raw) return void 0;
  const out = raw.split(",").map((s) => s.trim()).filter(Boolean);
  return out.length ? out : void 0;
}
function resolveLimit(requested) {
  const fallback = Number(process.env.JOBSPIPE_LIMIT || 25);
  const n = requested ?? (Number.isFinite(fallback) ? fallback : 25);
  return Math.min(Math.max(n, 1), 100);
}
function buildBody(f) {
  const titles = f.titles?.filter(Boolean) || envList("JOBSPIPE_TITLES") || (f.keywords?.length ? f.keywords : ["Software Engineer"]);
  const body = {
    job_title_or: titles,
    limit: resolveLimit(f.limit)
  };
  const excludeTitles = f.excludeTitles || envList("JOBSPIPE_EXCLUDE_TITLES");
  if (excludeTitles?.length) body.job_title_not = excludeTitles;
  if (f.keywords?.length && f.titles?.length) body.description_or = f.keywords;
  const companies = f.companies || envList("JOBSPIPE_COMPANIES");
  if (companies?.length) body.company_name_or = companies;
  const skills = f.skills || envList("JOBSPIPE_SKILLS");
  if (skills?.length) body.skills_or = skills;
  const locations = f.locations || envList("JOBSPIPE_LOCATIONS");
  if (locations?.length) body.job_location_or = locations;
  const countries = f.countries || envList("JOBSPIPE_COUNTRIES");
  if (countries?.length) body.job_country_code_or = countries;
  const sources = f.sources || envList("JOBSPIPE_SOURCES");
  if (sources?.length) body.source_or = sources;
  const excludeSources = f.excludeSources || envList("JOBSPIPE_EXCLUDE_SOURCES");
  if (excludeSources?.length) body.source_not = excludeSources;
  const seniority = f.seniority || envList("JOBSPIPE_SENIORITY");
  if (seniority?.length) body.job_seniority_or = seniority;
  const employment = f.employmentTypes || envList("JOBSPIPE_EMPLOYMENT_TYPES");
  if (employment?.length) body.employment_type_or = employment;
  const arrangements = f.workArrangements || envList("JOBSPIPE_WORK_ARRANGEMENTS");
  if (arrangements?.length) body.work_arrangement_or = arrangements;
  const remote = f.remoteOnly ?? process.env.JOBSPIPE_REMOTE_ONLY !== "0";
  if (remote) body.remote = true;
  const maxAge = f.maxAgeDays ?? Number(process.env.JOBSPIPE_MAX_AGE_DAYS || 14);
  if (Number.isFinite(maxAge) && maxAge > 0) {
    body.posted_at_max_age_days = maxAge;
  }
  if (f.includeTotal) body.include_total_results = true;
  return body;
}
async function fetchJobsPipeJobs(filters) {
  const key = jobspipeKey();
  if (!key) {
    return {
      jobs: [],
      error: "jobspipe: JOBSPIPE_API_KEY / JOBS_PIPE_KEY missing (optional)"
    };
  }
  const f = filters || {};
  const budget = monthlyBudget();
  const used = readLedger().jobs;
  const remaining = budget - used;
  if (remaining <= 0) {
    return {
      jobs: [],
      error: `jobspipe: monthly budget spent (${used}/${budget} jobs this month). Raise JOBSPIPE_MONTHLY_BUDGET, or reset the counter if the plan renewed.`
    };
  }
  const body = buildBody(f);
  body.limit = Math.min(body.limit, remaining);
  let data;
  try {
    await pace();
    const res = await fetch(SEARCH_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
      },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const hint = res.status === 429 ? " (rate limit is 2 req/s, or the monthly quota is gone)" : res.status === 401 || res.status === 403 ? " (check the jp_live_\u2026 key)" : "";
      return { jobs: [], error: `JobsPipe HTTP ${res.status}${hint}` };
    }
    data = await res.json();
  } catch (e) {
    return {
      jobs: [],
      error: `jobspipe: ${e instanceof Error ? e.message : String(e)}`
    };
  }
  const rows = data.data || [];
  spend(rows.length);
  const jobs = [];
  for (const j of rows) {
    const link = j.url || j.final_url || j.source_url;
    const title = j.job_title || j.normalized_title;
    if (!title || !link) continue;
    if (j.status && j.status !== "active") continue;
    const cur = j.salary_currency || "USD";
    const budgetStr = j.salary_string || (j.min_annual_salary && j.max_annual_salary ? `${j.min_annual_salary}\u2013${j.max_annual_salary} ${cur}/yr` : void 0);
    jobs.push({
      id: jobId("jobspipe", j.id || link),
      platform: "jobspipe",
      kind: "job",
      title: `${title}${j.company ? ` @ ${j.company}` : ""}`,
      description: (j.description || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 4e3),
      link,
      date: j.date_posted || j.discovered_at ? new Date(j.date_posted || j.discovered_at).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
      budget: budgetStr,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: {
        location: j.short_location || j.location,
        country: j.country,
        country_code: j.country_code,
        remote: j.remote,
        hybrid: j.hybrid,
        work_arrangement: j.work_arrangement,
        seniority: j.seniority,
        is_manager: j.is_manager,
        job_function: j.job_function,
        employment: j.employment_statuses,
        // Worth surfacing: these apply in one click, no ATS account needed.
        easy_apply: j.easy_apply,
        tech: j.technology_slugs,
        company_domain: j.company_domain,
        // The same role on LinkedIn and on the company's Greenhouse board comes
        // back as two rows with two ids — keep provenance for dedup upstream.
        sources: Array.isArray(j.sources) ? j.sources.map((s) => typeof s === "string" ? s : s?.name) : void 0,
        blurred: j.has_blurred_data || void 0
      }
    });
  }
  return {
    jobs,
    totalCount: data.metadata?.total_results ?? data.metadata?.truncated_results
  };
}

// src/module-entries/jobspipe.ts
var meta = {
  id: "jobspipe",
  version: "1.1.0",
  platforms: ["jobspipe"],
  envKeys: [
    "JOBSPIPE_API_KEY",
    "JOBS_PIPE_KEY",
    "JOBSPIPE_TITLES",
    "JOBSPIPE_EXCLUDE_TITLES",
    "JOBSPIPE_COMPANIES",
    "JOBSPIPE_SKILLS",
    "JOBSPIPE_LOCATIONS",
    "JOBSPIPE_COUNTRIES",
    "JOBSPIPE_SOURCES",
    "JOBSPIPE_EXCLUDE_SOURCES",
    "JOBSPIPE_SENIORITY",
    "JOBSPIPE_EMPLOYMENT_TYPES",
    "JOBSPIPE_WORK_ARRANGEMENTS",
    "JOBSPIPE_REMOTE_ONLY",
    "JOBSPIPE_MAX_AGE_DAYS",
    "JOBSPIPE_LIMIT",
    "JOBSPIPE_MONTHLY_BUDGET"
  ]
};
function configured() {
  return jobspipeConfigured();
}
function usage() {
  return jobspipeUsage();
}
function strList(v) {
  return Array.isArray(v) ? v.filter(Boolean) : void 0;
}
async function fetchJobs(_ctx, opts) {
  return fetchJobsPipeJobs({
    titles: strList(opts?.titles),
    excludeTitles: strList(opts?.excludeTitles),
    keywords: strList(opts?.keywords),
    companies: strList(opts?.companies),
    skills: strList(opts?.skills),
    locations: strList(opts?.locations),
    countries: strList(opts?.countries),
    sources: strList(opts?.sources),
    excludeSources: strList(opts?.excludeSources),
    seniority: strList(opts?.seniority),
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    remoteOnly: typeof opts?.remoteOnly === "boolean" ? opts.remoteOnly : void 0
  });
}
export {
  configured,
  fetchJobs,
  meta,
  usage
};
