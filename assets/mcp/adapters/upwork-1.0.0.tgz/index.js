// src/adapters/upwork.ts
import { existsSync as existsSync3, mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { join as join3 } from "node:path";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}

// src/store.ts
import { createHash } from "node:crypto";
import { existsSync as existsSync2, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function resolveDataDir() {
  if (process.env.WORKIX_MCP_DATA?.trim()) {
    return process.env.WORKIX_MCP_DATA.trim();
  }
  return join2(ROOT2, "data");
}
function storePath() {
  return join2(resolveDataDir(), "store.json");
}
function empty() {
  return { jobs: {}, drafts: [], shownDigestIds: [] };
}
function ensure() {
  const dir = resolveDataDir();
  if (!existsSync2(dir)) mkdirSync(dir, { recursive: true });
  const path = storePath();
  if (!existsSync2(path)) {
    writeFileSync(path, JSON.stringify(empty(), null, 2), "utf8");
  }
}
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}
function dataDir() {
  ensure();
  return resolveDataDir();
}

// src/adapters/upwork.ts
var GRAPHQL = "https://api.upwork.com/graphql";
var TOKEN_URL = "https://www.upwork.com/api/v3/oauth2/token";
var AUTH_URL = "https://www.upwork.com/ab/account-security/oauth2/authorize";
function tokenFile() {
  return join3(dataDir(), "upwork-tokens.json");
}
var memoryTokens = null;
function upworkConfigured() {
  loadEnv();
  return Boolean(
    process.env.UPWORK_CLIENT_ID?.trim() && process.env.UPWORK_CLIENT_SECRET?.trim() && (process.env.UPWORK_ACCESS_TOKEN?.trim() || process.env.UPWORK_REFRESH_TOKEN?.trim() || loadTokenFile()?.access_token || loadTokenFile()?.refresh_token)
  );
}
function loadTokenFile() {
  try {
    const path = tokenFile();
    if (!existsSync3(path)) return null;
    return JSON.parse(readFileSync2(path, "utf8"));
  } catch {
    return null;
  }
}
function saveTokenFile(t) {
  const dir = dataDir();
  mkdirSync2(dir, { recursive: true });
  writeFileSync2(
    tokenFile(),
    JSON.stringify({ ...t, updated_at: (/* @__PURE__ */ new Date()).toISOString() }, null, 2),
    "utf8"
  );
  memoryTokens = t;
}
function currentTokens() {
  loadEnv();
  const file = loadTokenFile();
  const mem = memoryTokens || file;
  return {
    access_token: mem?.access_token || process.env.UPWORK_ACCESS_TOKEN?.trim() || "",
    refresh_token: mem?.refresh_token || process.env.UPWORK_REFRESH_TOKEN?.trim() || "",
    expires_at: mem?.expires_at
  };
}
function upworkAuthUrl(state = "workix") {
  loadEnv();
  const clientId = process.env.UPWORK_CLIENT_ID?.trim() || "";
  const redirect = process.env.UPWORK_REDIRECT_URI?.trim() || "http://127.0.0.1:3456/callback";
  const params = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirect,
    state
  });
  return {
    url: `${AUTH_URL}?${params}`,
    redirect_uri: redirect,
    note: "\u041E\u0442\u043A\u0440\u043E\u0439 url, \u0430\u0432\u0442\u043E\u0440\u0438\u0437\u0443\u0439\u0441\u044F, \u0441\u043A\u043E\u043F\u0438\u0440\u0443\u0439 ?code= \u0438\u0437 redirect. \u0417\u0430\u0442\u0435\u043C workix_upwork_exchange_code \u0438\u043B\u0438 \u0441\u043A\u0440\u0438\u043F\u0442 npm run upwork:token."
  };
}
async function upworkExchangeCode(code) {
  loadEnv();
  const clientId = process.env.UPWORK_CLIENT_ID?.trim();
  const clientSecret = process.env.UPWORK_CLIENT_SECRET?.trim();
  const redirect = process.env.UPWORK_REDIRECT_URI?.trim() || "http://127.0.0.1:3456/callback";
  if (!clientId || !clientSecret) {
    return { ok: false, error: "UPWORK_CLIENT_ID/SECRET missing" };
  }
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirect
  });
  return persistTokenResponse(await postForm(TOKEN_URL, body));
}
async function refreshAccessToken() {
  loadEnv();
  const clientId = process.env.UPWORK_CLIENT_ID?.trim();
  const clientSecret = process.env.UPWORK_CLIENT_SECRET?.trim();
  const tokens = currentTokens();
  if (!clientId || !clientSecret) {
    return { ok: false, error: "UPWORK_CLIENT_ID/SECRET missing" };
  }
  if (!tokens.refresh_token) {
    if (tokens.access_token) {
      return { ok: true, access_token: tokens.access_token };
    }
    return { ok: false, error: "UPWORK_REFRESH_TOKEN / ACCESS_TOKEN missing" };
  }
  const stillValid = tokens.access_token && tokens.expires_at && tokens.expires_at > Date.now() + 6e4;
  if (stillValid) {
    return { ok: true, access_token: tokens.access_token };
  }
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: tokens.refresh_token,
    client_id: clientId,
    client_secret: clientSecret
  });
  const r = await persistTokenResponse(await postForm(TOKEN_URL, body));
  if (!r.ok) return { ok: false, error: r.error };
  return { ok: true, access_token: currentTokens().access_token };
}
async function persistTokenResponse(res) {
  if (!res.ok || !res.data?.access_token) {
    return {
      ok: false,
      error: res.error || "token exchange failed"
    };
  }
  const prev = currentTokens();
  const expiresIn = Number(res.data.expires_in || 86400);
  saveTokenFile({
    access_token: String(res.data.access_token),
    refresh_token: res.data.refresh_token ? String(res.data.refresh_token) : prev.refresh_token,
    expires_at: Date.now() + expiresIn * 1e3
  });
  return { ok: true, expires_in: expiresIn };
}
async function postForm(url, body) {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json"
      },
      body: body.toString()
    });
    const text = await res.text();
    let data = {};
    try {
      data = JSON.parse(text);
    } catch {
    }
    if (!res.ok) {
      return {
        ok: false,
        error: `HTTP ${res.status}: ${text.slice(0, 400)}`,
        data
      };
    }
    return { ok: true, data };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}
async function graphql(query, variables) {
  const tok = await refreshAccessToken();
  if (!tok.ok || !tok.access_token) {
    return { error: tok.error || "no access token" };
  }
  loadEnv();
  const headers = {
    Authorization: `Bearer ${tok.access_token}`,
    "Content-Type": "application/json",
    Accept: "application/json"
  };
  const tenant = process.env.UPWORK_TENANT_ID?.trim() || process.env.UPWORK_TEAM_ORG_ID?.trim();
  if (tenant) headers["X-Upwork-API-TenantId"] = tenant;
  try {
    const res = await fetch(GRAPHQL, {
      method: "POST",
      headers,
      body: JSON.stringify({ query, variables })
    });
    const text = await res.text();
    let json = {};
    try {
      json = JSON.parse(text);
    } catch {
      return { error: `GraphQL non-JSON HTTP ${res.status}: ${text.slice(0, 300)}` };
    }
    if (!res.ok) {
      return {
        error: `GraphQL HTTP ${res.status}: ${text.slice(0, 400)}`,
        errors: json.errors
      };
    }
    if (json.errors?.length) {
      return {
        error: json.errors.map((e) => e.message).join("; "),
        errors: json.errors,
        data: json.data
      };
    }
    return { data: json.data };
  } catch (e) {
    return { error: e instanceof Error ? e.message : String(e) };
  }
}
var SEARCH_QUERY = `
query SearchJobs($filter: MarketplaceJobPostingsSearchFilter) {
  marketplaceJobPostingsSearch(
    marketPlaceJobFilter: $filter
    searchType: USER_JOBS_SEARCH
    sortAttributes: [{ field: RECENCY }]
  ) {
    totalCount
    edges {
      node {
        id
        title
        description
        createdDateTime
        ciphertext
        amount { displayValue currency }
        skills { name }
      }
    }
  }
}
`;
async function fetchUpworkJobs(opts) {
  if (!upworkConfigured()) {
    return { jobs: [], error: "Upwork credentials missing (optional)" };
  }
  loadEnv();
  const q = opts?.query?.trim() || process.env.UPWORK_SEARCH?.trim() || "mobile OR flutter OR react native OR MVP OR telegram bot";
  const first = Math.min(Math.max(opts?.first ?? 20, 1), 50);
  const result = await graphql(SEARCH_QUERY, {
    filter: {
      searchExpression_eq: q,
      pagination_eq: { after: "0", first }
    }
  });
  if (result.error && !result.data?.marketplaceJobPostingsSearch) {
    return { jobs: [], error: result.error };
  }
  const edges = result.data?.marketplaceJobPostingsSearch?.edges || [];
  const jobs = [];
  for (const edge of edges) {
    const n = edge.node;
    if (!n?.title) continue;
    const cipher = n.ciphertext || n.id;
    const link = cipher ? `https://www.upwork.com/jobs/${cipher.startsWith("~") ? cipher : `~${cipher}`}` : `https://www.upwork.com/jobs/`;
    const budget = n.amount?.displayValue ? `${n.amount.displayValue}${n.amount.currency ? ` ${n.amount.currency}` : ""}` : void 0;
    jobs.push({
      id: jobId("upwork", link + (n.id || n.title)),
      platform: "upwork",
      kind: "gig",
      title: n.title,
      description: (n.description || "").slice(0, 4e3),
      link,
      date: n.createdDateTime || (/* @__PURE__ */ new Date()).toISOString(),
      budget,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: n
    });
  }
  return {
    jobs,
    totalCount: result.data?.marketplaceJobPostingsSearch?.totalCount,
    error: result.error
  };
}
async function upworkCompanySelector() {
  const r = await graphql(`query { companySelector { items { title organizationId } } }`);
  if (r.error && !r.data?.companySelector) {
    return { ok: false, error: r.error };
  }
  return { ok: true, items: r.data?.companySelector?.items || [] };
}
async function upworkCreateProposal(opts) {
  loadEnv();
  const contractorId = process.env.UPWORK_CONTRACTOR_ID?.trim();
  const oDeskUserID = process.env.UPWORK_ODESK_USER_ID?.trim();
  const teamOrgId = process.env.UPWORK_TEAM_ORG_ID?.trim() || process.env.UPWORK_TENANT_ID?.trim();
  if (!contractorId || !oDeskUserID || !teamOrgId) {
    return {
      ok: false,
      error: "\u0414\u043B\u044F API-proposal \u043D\u0443\u0436\u043D\u044B UPWORK_CONTRACTOR_ID, UPWORK_ODESK_USER_ID, UPWORK_TEAM_ORG_ID (\u0441\u043C. companySelector / docs).",
      browserHint: "browser"
    };
  }
  const mutation = `
    mutation createJobProposal($input: CreateJobProposalInput!) {
      createJobProposal(input: $input) {
        newProposalId
        status
        error
      }
    }
  `;
  const r = await graphql(mutation, {
    input: {
      selectedContractor: { id: contractorId, oDeskUserID },
      jobReference: opts.jobReference,
      chargedAmount: opts.chargedAmount,
      coverLetter: opts.coverLetter,
      teamOrgId,
      estimatedDuration: opts.estimatedDuration ?? 7
    }
  });
  if (r.error) {
    return { ok: false, error: r.error, raw: r.errors, browserHint: "browser" };
  }
  const status = r.data?.createJobProposal?.status;
  if (status && status !== "SUCCESS" && status !== "OK") {
    return {
      ok: false,
      error: `status=${status} error=${r.data?.createJobProposal?.error || "?"}`,
      raw: r.data,
      browserHint: "browser"
    };
  }
  return { ok: true, raw: r.data };
}
function upworkJobReference(job) {
  const raw = job.raw;
  return raw?.ciphertext || raw?.id;
}

// src/module-entries/upwork.ts
var meta = {
  id: "upwork",
  version: "1.0.0",
  platforms: ["upwork"],
  envKeys: [
    "UPWORK_CLIENT_ID",
    "UPWORK_CLIENT_SECRET",
    "UPWORK_REDIRECT_URI",
    "UPWORK_ACCESS_TOKEN",
    "UPWORK_REFRESH_TOKEN"
  ]
};
function configured() {
  return upworkConfigured();
}
async function fetchJobs(_ctx, opts) {
  return fetchUpworkJobs(opts);
}
function authUrl(state) {
  return upworkAuthUrl(state);
}
async function exchangeCode(code) {
  return upworkExchangeCode(code);
}
async function companySelector() {
  return upworkCompanySelector();
}
async function createProposal(opts) {
  return upworkCreateProposal(opts);
}
function jobReference(job) {
  return upworkJobReference(job);
}
export {
  authUrl,
  companySelector,
  configured,
  createProposal,
  exchangeCode,
  fetchJobs,
  jobReference,
  meta
};
