// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  const directFallback = opts?.directFallback !== false;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  if (directFallback) tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}

// src/store.ts
import { createHash } from "node:crypto";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/aquent.ts
var FEED_URL = "https://aquent.com/feeds/jobs.xml";
function decodeCdata(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/gi, "$1").replace(/&nbsp;/gi, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n))).replace(
    /&#x([0-9a-f]+);/gi,
    (_, n) => String.fromCharCode(parseInt(n, 16))
  ).trim();
}
function tag(block, name) {
  const re = new RegExp(`<${name}[^>]*>([\\s\\S]*?)</${name}>`, "i");
  const m = block.match(re);
  return m ? decodeCdata(m[1]) : "";
}
function stripHtml(html) {
  return decodeCdata(html).replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}
function isRemote(remotetype) {
  const t = remotetype.toLowerCase();
  if (!t) return false;
  if (/\bonsite\b/.test(t) && !/remote/.test(t)) return false;
  return /remote|hybrid/.test(t);
}
async function fetchAquentJobs(opts) {
  const count = Math.min(Math.max(opts?.count ?? 80, 1), 200);
  const remoteEnv = process.env.AQUENT_REMOTE_ONLY?.trim();
  const remoteOnly = opts?.remoteOnly ?? (remoteEnv === void 0 || remoteEnv === "" ? true : !["0", "false", "no"].includes(remoteEnv.toLowerCase()));
  const res = await fetchText(FEED_URL, {
    headers: {
      Accept: "application/rss+xml, application/xml, text/xml, */*",
      "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
    },
    proxy: false,
    timeoutMs: 6e4
  });
  if (!res.ok || !res.text) {
    return {
      jobs: [],
      error: res.error || `Aquent feed HTTP ${res.status}`
    };
  }
  const items = res.text.match(/<item[\s>][\s\S]*?<\/item>/gi) || [];
  const jobs = [];
  for (const block of items) {
    const jobIdRaw = tag(block, "job_id");
    const title = tag(block, "title");
    if (!jobIdRaw || !title) continue;
    const remotetype = tag(block, "remotetype");
    if (remoteOnly && !isRemote(remotetype)) continue;
    const city = tag(block, "city");
    const state = tag(block, "state");
    const country = tag(block, "country");
    const company = tag(block, "company") || "Aquent";
    const placement = tag(block, "placement_type");
    const description = stripHtml(tag(block, "description")).slice(0, 4e3);
    const pubDate = tag(block, "pubDate") || tag(block, "pubdate");
    const link = `https://aquent.com/find-work/${jobIdRaw}`;
    jobs.push({
      id: jobId("aquent", jobIdRaw),
      platform: "aquent",
      kind: "job",
      title: `${title} @ ${company}`,
      description,
      link,
      date: pubDate ? new Date(pubDate).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: {
        job_id: jobIdRaw,
        remotetype,
        placement_type: placement,
        location: [city, state, country].filter(Boolean).join(", "),
        credit: "Aquent job feed \u2014 credit Aquent when redistributing"
      }
    });
    if (jobs.length >= count) break;
  }
  if (!jobs.length) {
    return {
      jobs: [],
      error: items.length ? "Aquent: no items after remote filter" : "Aquent: empty feed"
    };
  }
  return { jobs };
}

// src/module-entries/aquent.ts
var meta = {
  id: "aquent",
  version: "1.0.0",
  platforms: ["aquent"],
  envKeys: ["AQUENT_REMOTE_ONLY"]
};
async function fetchJobs(_ctx, opts) {
  return fetchAquentJobs({
    count: typeof opts?.count === "number" ? opts.count : void 0,
    remoteOnly: typeof opts?.remoteOnly === "boolean" ? opts.remoteOnly : void 0
  });
}
export {
  fetchJobs,
  meta
};
