// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  const directFallback = opts?.directFallback !== false;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  if (directFallback) tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}
async function fetchJson(url, opts) {
  const res = await fetchText(url, opts);
  if (!res.ok) {
    return { error: res.error, status: res.status, ms: res.ms };
  }
  try {
    return { data: JSON.parse(res.text), status: res.status, ms: res.ms };
  } catch (e) {
    return {
      error: e instanceof Error ? e.message : "JSON parse error",
      status: res.status,
      ms: res.ms
    };
  }
}

// src/store.ts
import { createHash } from "node:crypto";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/rentahuman.ts
async function fetchRentAHumanJobs(opts) {
  const pageSize = Math.min(Math.max(opts?.limit ?? 25, 1), 50);
  const maxPages = Math.min(Math.max(opts?.pages ?? 2, 1), 4);
  const jobs = [];
  let cursor;
  for (let page = 0; page < maxPages; page++) {
    const qs = new URLSearchParams({ limit: String(pageSize) });
    if (cursor) qs.set("cursor", cursor);
    const url = `https://rentahuman.ai/api/bounties?${qs}`;
    const { data, error, status } = await fetchJson(url, {
      headers: {
        Accept: "application/json",
        "User-Agent": "WorkixMCP/0.1 (dev@workix.co)"
      },
      proxy: false
    });
    if (error || !data?.bounties || !Array.isArray(data.bounties)) {
      if (!jobs.length) {
        return { jobs: [], error: error || `RentAHuman HTTP ${status}` };
      }
      break;
    }
    for (const row of data.bounties) {
      if (!row.title || !row.id) continue;
      if (row.status && !/open|partially/i.test(row.status)) continue;
      const link = `https://rentahuman.ai/bounties/${row.id}`;
      const budget = row.price != null ? `${row.price} ${row.currency || "USD"}${row.priceType ? ` (${row.priceType})` : ""}` : void 0;
      const dateRaw = row.wentLiveAt || row.createdAt || row.deadline;
      const loc = row.location?.isRemoteAllowed ? "remote ok" : row.location?.country || "";
      jobs.push({
        id: jobId("rentahuman", row.id),
        platform: "rentahuman",
        kind: "gig",
        title: row.agentName ? `${row.title} (by ${row.agentName})` : row.title,
        description: [
          row.description || "",
          row.category ? `category: ${row.category}` : "",
          loc ? `location: ${loc}` : "",
          row.skillsNeeded?.length ? `skills: ${row.skillsNeeded.join(", ")}` : ""
        ].filter(Boolean).join("\n").replace(/\s+/g, " ").trim().slice(0, 4e3),
        link,
        date: dateRaw ? new Date(dateRaw).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
        budget,
        fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
        raw: {
          status: row.status,
          agentType: row.agentType,
          spotsRemaining: row.spotsRemaining,
          category: row.category
        }
      });
    }
    if (!data.hasMore || !data.nextCursor) break;
    cursor = data.nextCursor;
  }
  return { jobs };
}

// src/module-entries/rentahuman.ts
var meta = {
  id: "rentahuman",
  version: "1.0.0",
  platforms: ["rentahuman"]
};
async function fetchJobs(_ctx, opts) {
  return fetchRentAHumanJobs({
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    pages: typeof opts?.pages === "number" ? opts.pages : void 0
  });
}
export {
  fetchJobs,
  meta
};
