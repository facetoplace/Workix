// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/cookies.ts
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync } from "node:fs";
import { join as join2 } from "node:path";

// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { existsSync, mkdirSync, readFileSync, renameSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function resolveDataDir() {
  const fromEnv = process.env.WORKIX_MCP_DATA?.trim();
  return fromEnv || join(ROOT, "data");
}
var handle = null;
var SCHEMA = `
CREATE TABLE IF NOT EXISTS jobs (
  id              TEXT PRIMARY KEY,
  platform        TEXT NOT NULL,
  kind            TEXT,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL DEFAULT '',
  link            TEXT NOT NULL,
  date            TEXT NOT NULL,
  budget          TEXT,
  raw             TEXT,
  fetched_at      TEXT NOT NULL,
  seen_at         TEXT NOT NULL,
  shown_in_digest INTEGER NOT NULL DEFAULT 0,
  hub_share       TEXT
);
CREATE INDEX IF NOT EXISTS jobs_platform ON jobs(platform);
CREATE INDEX IF NOT EXISTS jobs_date ON jobs(date DESC);
CREATE INDEX IF NOT EXISTS jobs_link ON jobs(link);
CREATE INDEX IF NOT EXISTS jobs_seen ON jobs(seen_at DESC);

CREATE TABLE IF NOT EXISTS shown_digest (
  id TEXT PRIMARY KEY,
  at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS drafts (
  rowid_alias INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id      TEXT NOT NULL,
  text        TEXT NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS drafts_job ON drafts(job_id, created_at DESC);

CREATE TABLE IF NOT EXISTS outreach (
  id      TEXT PRIMARY KEY,
  at      TEXT NOT NULL,
  status  TEXT NOT NULL,
  channel TEXT NOT NULL,
  contact TEXT NOT NULL,
  text    TEXT NOT NULL,
  project TEXT,
  url     TEXT,
  job_id  TEXT,
  note    TEXT
);
CREATE INDEX IF NOT EXISTS outreach_at ON outreach(at DESC);

CREATE TABLE IF NOT EXISTS checkpoints (
  id       TEXT PRIMARY KEY,
  at       TEXT NOT NULL,
  summary  TEXT NOT NULL,
  next     TEXT,
  surfaces TEXT,
  batch    TEXT,
  blocked  TEXT,
  note     TEXT
);
CREATE INDEX IF NOT EXISTS checkpoints_at ON checkpoints(at DESC);

CREATE TABLE IF NOT EXISTS hub_shares (
  id           TEXT PRIMARY KEY,
  at           TEXT NOT NULL,
  job_id       TEXT NOT NULL,
  platform     TEXT NOT NULL,
  title        TEXT NOT NULL,
  external_url TEXT NOT NULL,
  sid          TEXT NOT NULL,
  hub_url      TEXT NOT NULL,
  hub_id       TEXT,
  status       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS hub_shares_at ON hub_shares(at DESC);
CREATE INDEX IF NOT EXISTS hub_shares_job ON hub_shares(job_id);

CREATE TABLE IF NOT EXISTS fetch_cache (
  key        TEXT PRIMARY KEY,
  source     TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  items      INTEGER NOT NULL DEFAULT 0,
  payload    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS fetch_cache_source ON fetch_cache(source);
CREATE INDEX IF NOT EXISTS fetch_cache_expires ON fetch_cache(expires_at);

CREATE TABLE IF NOT EXISTS meta (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);
`;
function db() {
  const dir = resolveDataDir();
  if (handle && handle.dir === dir) return handle.db;
  if (handle) handle.db.close();
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  const conn = new DatabaseSync(join(dir, "workix.db"));
  conn.exec("PRAGMA journal_mode = WAL");
  conn.exec("PRAGMA busy_timeout = 5000");
  conn.exec("PRAGMA foreign_keys = ON");
  conn.exec(SCHEMA);
  handle = { db: conn, dir };
  migrateStoreJson(conn, dir);
  return conn;
}
function nullable(v) {
  if (v === void 0 || v === null || v === "") return null;
  return typeof v === "string" ? v : JSON.stringify(v);
}
function migrateStoreJson(conn, dir) {
  const already = conn.prepare("SELECT v FROM meta WHERE k = 'migrated_store_json'").get();
  if (already) return;
  const legacy = join(dir, "store.json");
  if (!existsSync(legacy)) {
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run((/* @__PURE__ */ new Date()).toISOString());
    return;
  }
  let data;
  try {
    data = JSON.parse(readFileSync(legacy, "utf8"));
  } catch {
    return;
  }
  const jobs = Object.values(
    data.jobs || {}
  );
  const insJob = conn.prepare(
    `INSERT OR REPLACE INTO jobs
     (id, platform, kind, title, description, link, date, budget, raw, fetched_at, seen_at, shown_in_digest, hub_share)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShown = conn.prepare(
    "INSERT OR IGNORE INTO shown_digest (id, at) VALUES (?, ?)"
  );
  const insDraft = conn.prepare(
    "INSERT INTO drafts (job_id, text, created_at) VALUES (?, ?, ?)"
  );
  const insOutreach = conn.prepare(
    `INSERT OR REPLACE INTO outreach (id, at, status, channel, contact, text, project, url, job_id, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insCheckpoint = conn.prepare(
    `INSERT OR REPLACE INTO checkpoints (id, at, summary, next, surfaces, batch, blocked, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShare = conn.prepare(
    `INSERT OR REPLACE INTO hub_shares (id, at, job_id, platform, title, external_url, sid, hub_url, hub_id, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const now = (/* @__PURE__ */ new Date()).toISOString();
  conn.exec("BEGIN");
  try {
    for (const j of jobs) {
      if (!j?.id || !j?.title || !j?.link) continue;
      insJob.run(
        String(j.id),
        String(j.platform || "unknown"),
        nullable(j.kind),
        String(j.title),
        String(j.description || ""),
        String(j.link),
        String(j.date || now),
        nullable(j.budget),
        j.raw === void 0 ? null : JSON.stringify(j.raw),
        String(j.fetchedAt || now),
        String(j.seenAt || now),
        j.shownInDigest ? 1 : 0,
        j.hubShare ? JSON.stringify(j.hubShare) : null
      );
    }
    for (const id of data.shownDigestIds || []) {
      insShown.run(String(id), now);
    }
    for (const d of data.drafts || []) {
      if (!d?.jobId) continue;
      insDraft.run(String(d.jobId), String(d.text || ""), String(d.createdAt || now));
    }
    for (const o of data.outreach || []) {
      if (!o?.id) continue;
      insOutreach.run(
        String(o.id),
        String(o.at || now),
        String(o.status || "draft"),
        String(o.channel || ""),
        String(o.contact || ""),
        String(o.text || ""),
        nullable(o.project),
        nullable(o.url),
        nullable(o.jobId),
        nullable(o.note)
      );
    }
    for (const c of data.checkpoints || []) {
      if (!c?.id) continue;
      insCheckpoint.run(
        String(c.id),
        String(c.at || now),
        String(c.summary || ""),
        nullable(c.next),
        c.surfaces ? JSON.stringify(c.surfaces) : null,
        nullable(c.batch),
        c.blocked ? JSON.stringify(c.blocked) : null,
        nullable(c.note)
      );
    }
    for (const h of data.hubShares || []) {
      if (!h?.id) continue;
      insShare.run(
        String(h.id),
        String(h.at || now),
        String(h.jobId || ""),
        String(h.platform || ""),
        String(h.title || ""),
        String(h.externalUrl || ""),
        String(h.sid || ""),
        String(h.hubUrl || ""),
        nullable(h.hubId),
        String(h.status || "created")
      );
    }
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run(now);
    conn.exec("COMMIT");
  } catch (e) {
    conn.exec("ROLLBACK");
    throw e;
  }
  try {
    renameSync(legacy, `${legacy}.migrated`);
  } catch {
  }
  if (process.env.WORKIX_MCP_DEBUG) {
    console.error(`[workix] migrated ${jobs.length} jobs from store.json \u2192 workix.db`);
  }
}

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}
function dataDir() {
  db();
  return resolveDataDir();
}

// src/cookies.ts
function cookiesDir() {
  const dir = join2(dataDir(), "cookies");
  if (!existsSync2(dir)) mkdirSync2(dir, { recursive: true });
  return dir;
}
function jarPath(jar) {
  return join2(cookiesDir(), `${jar}.json`);
}
function loadCookies(jar) {
  const file = jarPath(jar);
  if (!existsSync2(file)) return [];
  try {
    const parsed = JSON.parse(readFileSync2(file, "utf8"));
    return Array.isArray(parsed.cookies) ? parsed.cookies : [];
  } catch {
    return [];
  }
}
function saveCookies(jar, cookies) {
  const body = {
    jar,
    updated: (/* @__PURE__ */ new Date()).toISOString(),
    cookies
  };
  writeFileSync(jarPath(jar), JSON.stringify(body, null, 2), "utf8");
}
function domainMatches(cookieDomain, host) {
  const d = cookieDomain.replace(/^\./, "").toLowerCase();
  const h = host.toLowerCase();
  return h === d || h.endsWith(`.${d}`);
}
function pathMatches(cookiePath, urlPath) {
  const c = cookiePath || "/";
  if (c === "/") return true;
  if (urlPath === c) return true;
  return urlPath.startsWith(c.endsWith("/") ? c : `${c}/`);
}
function notExpired(c, nowSec) {
  if (c.expires == null || c.expires <= 0) return true;
  return c.expires > nowSec;
}
function cookieHeaderFor(jar, url) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return void 0;
  }
  const nowSec = Math.floor(Date.now() / 1e3);
  const secure = u.protocol === "https:";
  const matched = loadCookies(jar).filter(
    (c) => domainMatches(c.domain, u.hostname) && pathMatches(c.path, u.pathname) && notExpired(c, nowSec) && (secure || !c.secure)
  );
  if (!matched.length) return void 0;
  matched.sort((a, b) => (b.path || "/").length - (a.path || "/").length);
  const seen = /* @__PURE__ */ new Set();
  const parts = [];
  for (const c of matched) {
    if (seen.has(c.name)) continue;
    seen.add(c.name);
    parts.push(`${c.name}=${c.value}`);
  }
  return parts.join("; ");
}
function parseSetCookie(line, url) {
  const [pair, ...attrs] = line.split(";");
  const eq = pair.indexOf("=");
  if (eq < 1) return void 0;
  let host;
  let defaultPath = "/";
  try {
    const u = new URL(url);
    host = u.hostname;
    defaultPath = u.pathname.replace(/\/[^/]*$/, "") || "/";
  } catch {
    return void 0;
  }
  const cookie = {
    name: pair.slice(0, eq).trim(),
    value: pair.slice(eq + 1).trim(),
    domain: host,
    path: defaultPath
  };
  for (const raw of attrs) {
    const [k, ...rest] = raw.split("=");
    const key = k.trim().toLowerCase();
    const val = rest.join("=").trim();
    if (key === "domain" && val) cookie.domain = val.replace(/^\./, "");
    else if (key === "path" && val) cookie.path = val;
    else if (key === "secure") cookie.secure = true;
    else if (key === "httponly") cookie.httpOnly = true;
    else if (key === "max-age" && val) {
      const secs = Number(val);
      if (Number.isFinite(secs)) {
        cookie.expires = Math.floor(Date.now() / 1e3) + secs;
      }
    } else if (key === "expires" && val && cookie.expires == null) {
      const t = Date.parse(val);
      if (!Number.isNaN(t)) cookie.expires = Math.floor(t / 1e3);
    }
  }
  return cookie;
}
function mergeSetCookie(jar, url, setCookie) {
  if (!setCookie) return;
  const lines = Array.isArray(setCookie) ? setCookie : [setCookie];
  if (!lines.length) return;
  const existing = loadCookies(jar);
  let changed = false;
  for (const line of lines) {
    const parsed = parseSetCookie(line, url);
    if (!parsed) continue;
    const idx = existing.findIndex(
      (c) => c.name === parsed.name && c.domain.replace(/^\./, "") === parsed.domain && c.path === parsed.path
    );
    const deleted = !parsed.value && parsed.expires != null && parsed.expires <= Math.floor(Date.now() / 1e3);
    if (deleted) {
      if (idx >= 0) {
        existing.splice(idx, 1);
        changed = true;
      }
      continue;
    }
    if (idx >= 0) existing[idx] = parsed;
    else existing.push(parsed);
    changed = true;
  }
  if (changed) saveCookies(jar, existing);
}

// src/env.ts
import { config } from "dotenv";
import { existsSync as existsSync3 } from "node:fs";
import { dirname as dirname2, join as join3 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join3(dirname2(fileURLToPath2(import.meta.url)), "..");
var REPO_ROOT = join3(ROOT2, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join3(ROOT2, ".env");
  const rootEnv = join3(REPO_ROOT, ".env");
  if (existsSync3(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync3(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  const directFallback = opts?.directFallback !== false;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs, cookieJar: opts?.cookieJar });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs,
      cookieJar: opts.cookieJar
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  if (directFallback) tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs,
      cookieJar: opts?.cookieJar
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const jarHeader = opts.cookieJar ? cookieHeaderFor(opts.cookieJar, url) : void 0;
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...jarHeader ? { Cookie: jarHeader } : {},
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (opts.cookieJar) {
            mergeSetCookie(opts.cookieJar, url, res.headers["set-cookie"]);
          }
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              finalUrl: url,
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}

// src/adapters/dreamoffer.ts
var BASE = "https://find.dreamoffer.app";
function headers(lang) {
  return {
    Accept: "application/json, text/html;q=0.9",
    "User-Agent": "WorkixMCP/0.1 (dev@workix.co)",
    "X-Lang": lang,
    Referer: `${BASE}/`,
    Origin: BASE
  };
}
function titleFromText(text) {
  const line = text.replace(/\*\*/g, "").split("\n").map((s) => s.trim()).find(Boolean);
  return (line || "Dream Offer vacancy").slice(0, 200);
}
function rowToJob(row) {
  if (!Array.isArray(row) || row.length < 11) return null;
  const nn = Number(row[0]);
  if (!Number.isFinite(nn)) return null;
  const link = String(row[7] || "").trim();
  const text = String(row[10] || "");
  const info = row[12] || {};
  const source = String(row[6] || "");
  const created = String(row[3] || row[2] || "");
  const channel = String(row[9] || "");
  const dreamUrl = `${BASE}/vacancy.html?nn=${nn}`;
  const budget = info.salary?.raw || void 0;
  const prof = info.profession || "";
  const grade = info.grade && info.grade !== "unknown" ? info.grade : "";
  const titleBits = [titleFromText(text), prof && `(${prof})`, grade].filter(Boolean);
  return {
    id: jobId("dreamoffer", dreamUrl),
    platform: "dreamoffer",
    kind: "job",
    title: titleBits.join(" "),
    description: text.replace(/\s+/g, " ").trim().slice(0, 4e3),
    link: dreamUrl,
    date: created ? new Date(created).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    budget,
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    raw: {
      nn,
      source,
      source_link: link || void 0,
      channel,
      profession: info.profession,
      grade: info.grade,
      work_format: info.work_format,
      employment_type: info.employment_type,
      country: info.country,
      city: info.city,
      language: info.language,
      apply: "source"
      // Dream Offer has no native apply — open source_link
    }
  };
}
function ssrToJob(v) {
  const nn = Number(v.nn);
  if (!Number.isFinite(nn)) return null;
  const text = String(v.vacancy_text || "");
  const info = v.vacancy_info || {};
  const dreamUrl = `${BASE}/vacancy.html?nn=${nn}`;
  const created = v.time_of_created || v.time_in_channel || "";
  const prof = info.profession || "";
  const grade = info.grade && info.grade !== "unknown" ? info.grade : "";
  return {
    id: jobId("dreamoffer", dreamUrl),
    platform: "dreamoffer",
    kind: "job",
    title: [titleFromText(text), prof && `(${prof})`, grade].filter(Boolean).join(" "),
    description: text.replace(/\s+/g, " ").trim().slice(0, 4e3),
    link: dreamUrl,
    date: created ? new Date(created).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    budget: info.salary?.raw || void 0,
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    raw: {
      nn,
      source: v.source,
      source_link: v.link,
      channel: v.tg_name_channel,
      profession: info.profession,
      grade: info.grade,
      work_format: info.work_format,
      apply: "source"
    }
  };
}
function matchesFilters(job, opts) {
  const raw = job.raw || {};
  const hay = `${job.title}
${job.description}
${raw.profession || ""}
${raw.grade || ""}`.toLowerCase();
  if (opts.workFormat && opts.workFormat !== "all") {
    const wf = String(raw.work_format || "").toLowerCase();
    if (wf && wf !== "unknown" && wf !== opts.workFormat.toLowerCase()) return false;
  }
  if (opts.profession && opts.profession !== "all") {
    const want = opts.profession.toLowerCase();
    const prof = String(raw.profession || "").toLowerCase();
    const mobileAliases = want === "mobile" || want === "developer mobile" || want === "mobile developer";
    if (mobileAliases) {
      const titleHay = job.title.toLowerCase();
      const profOk = /\bmobile\b/.test(prof);
      const titleOk = /\b(mobile|flutter|android|swift|kotlin|kmp)\b|react\s*native|\bios\b/.test(
        titleHay
      );
      if (!profOk && !titleOk) return false;
    } else if (prof && !prof.includes(want) && !hay.includes(want)) {
      return false;
    }
  }
  if (opts.keywords?.length) {
    const ok = opts.keywords.some((k) => hay.includes(k.toLowerCase()));
    if (!ok) return false;
  }
  return true;
}
async function fetchInitialDataset(lang) {
  const res = await fetchText(`${BASE}/initial-dataset`, {
    headers: headers(lang),
    proxy: false,
    timeoutMs: 45e3
  });
  if (!res.ok) {
    return { pages: [], nn: [], error: `Dream Offer initial-dataset HTTP ${res.status}` };
  }
  try {
    const data = JSON.parse(res.text);
    const pageMap = data.pages_payload?.pages || {};
    const pages = [];
    const keys = Object.keys(pageMap).sort((a, b) => {
      if (a === "last") return 1;
      if (b === "last") return -1;
      return Number(a) - Number(b);
    });
    for (const k of keys) {
      const chunk = pageMap[k];
      if (Array.isArray(chunk)) pages.push(...chunk);
    }
    return {
      pages,
      nn: Array.isArray(data.nn_payload?.nn) ? data.nn_payload.nn : []
    };
  } catch (e) {
    return { pages: [], nn: [], error: `Dream Offer JSON: ${e.message}` };
  }
}
async function fetchVacancySsr(nn, lang) {
  const res = await fetchText(`${BASE}/vacancy.html?nn=${nn}`, {
    headers: { ...headers(lang), Accept: "text/html" },
    proxy: false,
    timeoutMs: 2e4
  });
  if (!res.ok) return null;
  const m = res.text.match(/__VACANCY_SSR__\s*=\s*(\{[\s\S]*?\});?\s*<\/script>/);
  if (!m) return null;
  try {
    return ssrToJob(JSON.parse(m[1]));
  } catch {
    return null;
  }
}
async function mapPool(items, concurrency, fn) {
  const out = [];
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const idx = i++;
      const r = await fn(items[idx]);
      if (r != null) out.push(r);
    }
  }
  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  );
  return out;
}
async function fetchDreamOfferJobs(opts) {
  const limit = Math.min(Math.max(opts?.limit ?? 30, 1), 80);
  const lang = (opts?.lang || process.env.DREAMOFFER_LANG || "ru").trim() || "ru";
  const profession = opts?.profession?.trim() || process.env.DREAMOFFER_PROFESSION?.trim() || "Mobile";
  const workFormat = opts?.workFormat?.trim() || process.env.DREAMOFFER_WORK_FORMAT?.trim() || "remote";
  const scanExtra = Math.min(
    Math.max(
      opts?.scanExtra ?? (process.env.DREAMOFFER_SCAN_EXTRA ? Number(process.env.DREAMOFFER_SCAN_EXTRA) : 40),
      0
    ),
    120
  );
  const { pages, nn, error } = await fetchInitialDataset(lang);
  if (error && !pages.length) return { jobs: [], error };
  const filters = {
    profession: profession || void 0,
    workFormat: workFormat || void 0,
    keywords: opts?.keywords
  };
  const seen = /* @__PURE__ */ new Set();
  const jobs = [];
  for (const row of pages) {
    const job = rowToJob(row);
    if (!job || seen.has(job.id)) continue;
    if (!matchesFilters(job, filters)) continue;
    seen.add(job.id);
    jobs.push(job);
    if (jobs.length >= limit) break;
  }
  if (jobs.length < limit && scanExtra > 0 && nn.length) {
    const pageNns = new Set(
      pages.map((r) => Number(Array.isArray(r) ? r[0] : NaN)).filter(Number.isFinite)
    );
    const toScan = nn.filter((id) => !pageNns.has(id)).slice(0, scanExtra);
    const hydrated = await mapPool(toScan, 8, async (id) => {
      const job = await fetchVacancySsr(id, lang);
      if (!job || seen.has(job.id)) return null;
      if (!matchesFilters(job, filters)) return null;
      return job;
    });
    for (const job of hydrated) {
      if (seen.has(job.id)) continue;
      seen.add(job.id);
      jobs.push(job);
      if (jobs.length >= limit) break;
    }
  }
  jobs.sort((a, b) => b.date.localeCompare(a.date));
  return {
    jobs: jobs.slice(0, limit),
    ...error ? { error } : {}
  };
}

// src/module-entries/dreamoffer.ts
var meta = {
  id: "dreamoffer",
  version: "1.0.0",
  platforms: ["dreamoffer"]
};
async function fetchJobs(_ctx, opts) {
  return fetchDreamOfferJobs({
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    profession: typeof opts?.profession === "string" ? opts.profession : void 0,
    workFormat: typeof opts?.workFormat === "string" ? opts.workFormat : typeof opts?.work_format === "string" ? opts.work_format : void 0,
    keywords: Array.isArray(opts?.keywords) ? opts.keywords.filter((x) => typeof x === "string") : void 0,
    lang: typeof opts?.lang === "string" ? opts.lang : void 0,
    scanExtra: typeof opts?.scanExtra === "number" ? opts.scanExtra : void 0
  });
}
export {
  fetchJobs,
  meta
};
