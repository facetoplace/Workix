// src/http.ts
import http from "node:http";
import https from "node:https";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/http.ts
var DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
function makeAgent(proxy) {
  if (!proxy) return void 0;
  const p = proxy.trim();
  if (/^socks/i.test(p)) {
    return new SocksProxyAgent(p);
  }
  const normalized = /^https?:\/\//i.test(p) ? p : `http://${p}`;
  return new HttpsProxyAgent(normalized);
}
async function fetchText(url, opts) {
  const timeoutMs = opts?.timeoutMs ?? 2e4;
  const maxProxies = opts?.maxProxies ?? 6;
  const directFallback = opts?.directFallback !== false;
  let last = {
    ok: false,
    status: 0,
    text: "",
    ms: 0,
    viaProxy: false,
    error: "no attempt"
  };
  if (opts?.proxy === false) {
    return once(url, { headers: opts?.headers, timeoutMs });
  }
  if (typeof opts?.proxy === "string") {
    return once(url, {
      headers: opts.headers,
      proxy: opts.proxy,
      timeoutMs
    });
  }
  const pool = await getProxyPool();
  const tryList = [];
  for (let i = 0; i < Math.min(maxProxies, Math.max(pool.length, 1)); i++) {
    tryList.push(pool.length ? await nextProxy() : void 0);
  }
  if (directFallback) tryList.push(void 0);
  const seen = /* @__PURE__ */ new Set();
  for (const useProxy of tryList) {
    const key = useProxy || "__direct__";
    if (seen.has(key)) continue;
    seen.add(key);
    last = await once(url, {
      headers: opts?.headers,
      proxy: useProxy,
      timeoutMs
    });
    if (last.ok) return last;
    const softFail = last.status === 0 || last.status === 403 || last.status === 404 || last.status >= 500;
    if (!softFail) break;
  }
  if (!last.ok && last.status === 403 && !pool.length) {
    last.error = `${last.error || "403"}; \u0437\u0430\u0434\u0430\u0439\u0442\u0435 PROXY_1 (\u043F\u043E\u0434\u043F\u0438\u0441\u043A\u0430/socks)`;
  }
  return last;
}
function once(url, opts) {
  const started = Date.now();
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const lib = u.protocol === "http:" ? http : https;
      const agent = makeAgent(opts.proxy);
      const req = lib.request(
        url,
        {
          method: "GET",
          agent,
          headers: {
            "User-Agent": DEFAULT_UA,
            Accept: "*/*",
            "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
            ...opts.headers || {}
          },
          timeout: opts.timeoutMs
        },
        (res) => {
          const status = res.statusCode || 0;
          if (status >= 301 && status <= 308 && res.headers.location) {
            const next = new URL(res.headers.location, url).toString();
            res.resume();
            once(next, opts).then(resolve);
            return;
          }
          const chunks = [];
          res.on("data", (c) => chunks.push(c));
          res.on("end", () => {
            const text = Buffer.concat(chunks).toString("utf8");
            resolve({
              ok: status >= 200 && status < 300,
              status,
              text,
              ms: Date.now() - started,
              viaProxy: Boolean(opts.proxy),
              error: status >= 200 && status < 300 ? void 0 : `Status code ${status}`
            });
          });
        }
      );
      req.on("timeout", () => {
        req.destroy();
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: `Request timed out after ${opts.timeoutMs}ms`
        });
      });
      req.on("error", (e) => {
        resolve({
          ok: false,
          status: 0,
          text: "",
          ms: Date.now() - started,
          viaProxy: Boolean(opts.proxy),
          error: e.message
        });
      });
      req.end();
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        text: "",
        ms: Date.now() - started,
        viaProxy: Boolean(opts.proxy),
        error: e instanceof Error ? e.message : String(e)
      });
    }
  });
}

// src/store.ts
import { createHash } from "node:crypto";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/dreamoffer.ts
var BASE = "https://find.dreamoffer.app";
function headers(lang) {
  return {
    Accept: "application/json, text/html;q=0.9",
    "User-Agent": "WorkixMCP/0.1 (dev@workix.co)",
    "X-Lang": lang,
    Referer: `${BASE}/`,
    Origin: BASE
  };
}
function titleFromText(text) {
  const line = text.replace(/\*\*/g, "").split("\n").map((s) => s.trim()).find(Boolean);
  return (line || "Dream Offer vacancy").slice(0, 200);
}
function rowToJob(row) {
  if (!Array.isArray(row) || row.length < 11) return null;
  const nn = Number(row[0]);
  if (!Number.isFinite(nn)) return null;
  const link = String(row[7] || "").trim();
  const text = String(row[10] || "");
  const info = row[12] || {};
  const source = String(row[6] || "");
  const created = String(row[3] || row[2] || "");
  const channel = String(row[9] || "");
  const dreamUrl = `${BASE}/vacancy.html?nn=${nn}`;
  const budget = info.salary?.raw || void 0;
  const prof = info.profession || "";
  const grade = info.grade && info.grade !== "unknown" ? info.grade : "";
  const titleBits = [titleFromText(text), prof && `(${prof})`, grade].filter(Boolean);
  return {
    id: jobId("dreamoffer", dreamUrl),
    platform: "dreamoffer",
    kind: "job",
    title: titleBits.join(" "),
    description: text.replace(/\s+/g, " ").trim().slice(0, 4e3),
    link: dreamUrl,
    date: created ? new Date(created).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    budget,
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    raw: {
      nn,
      source,
      source_link: link || void 0,
      channel,
      profession: info.profession,
      grade: info.grade,
      work_format: info.work_format,
      employment_type: info.employment_type,
      country: info.country,
      city: info.city,
      language: info.language,
      apply: "source"
      // Dream Offer has no native apply — open source_link
    }
  };
}
function ssrToJob(v) {
  const nn = Number(v.nn);
  if (!Number.isFinite(nn)) return null;
  const text = String(v.vacancy_text || "");
  const info = v.vacancy_info || {};
  const dreamUrl = `${BASE}/vacancy.html?nn=${nn}`;
  const created = v.time_of_created || v.time_in_channel || "";
  const prof = info.profession || "";
  const grade = info.grade && info.grade !== "unknown" ? info.grade : "";
  return {
    id: jobId("dreamoffer", dreamUrl),
    platform: "dreamoffer",
    kind: "job",
    title: [titleFromText(text), prof && `(${prof})`, grade].filter(Boolean).join(" "),
    description: text.replace(/\s+/g, " ").trim().slice(0, 4e3),
    link: dreamUrl,
    date: created ? new Date(created).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    budget: info.salary?.raw || void 0,
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    raw: {
      nn,
      source: v.source,
      source_link: v.link,
      channel: v.tg_name_channel,
      profession: info.profession,
      grade: info.grade,
      work_format: info.work_format,
      apply: "source"
    }
  };
}
function matchesFilters(job, opts) {
  const raw = job.raw || {};
  const hay = `${job.title}
${job.description}
${raw.profession || ""}
${raw.grade || ""}`.toLowerCase();
  if (opts.workFormat && opts.workFormat !== "all") {
    const wf = String(raw.work_format || "").toLowerCase();
    if (wf && wf !== "unknown" && wf !== opts.workFormat.toLowerCase()) return false;
  }
  if (opts.profession && opts.profession !== "all") {
    const want = opts.profession.toLowerCase();
    const prof = String(raw.profession || "").toLowerCase();
    const mobileAliases = want === "mobile" || want === "developer mobile" || want === "mobile developer";
    if (mobileAliases) {
      const titleHay = job.title.toLowerCase();
      const profOk = /\bmobile\b/.test(prof);
      const titleOk = /\b(mobile|flutter|android|swift|kotlin|kmp)\b|react\s*native|\bios\b/.test(
        titleHay
      );
      if (!profOk && !titleOk) return false;
    } else if (prof && !prof.includes(want) && !hay.includes(want)) {
      return false;
    }
  }
  if (opts.keywords?.length) {
    const ok = opts.keywords.some((k) => hay.includes(k.toLowerCase()));
    if (!ok) return false;
  }
  return true;
}
async function fetchInitialDataset(lang) {
  const res = await fetchText(`${BASE}/initial-dataset`, {
    headers: headers(lang),
    proxy: false,
    timeoutMs: 45e3
  });
  if (!res.ok) {
    return { pages: [], nn: [], error: `Dream Offer initial-dataset HTTP ${res.status}` };
  }
  try {
    const data = JSON.parse(res.text);
    const pageMap = data.pages_payload?.pages || {};
    const pages = [];
    const keys = Object.keys(pageMap).sort((a, b) => {
      if (a === "last") return 1;
      if (b === "last") return -1;
      return Number(a) - Number(b);
    });
    for (const k of keys) {
      const chunk = pageMap[k];
      if (Array.isArray(chunk)) pages.push(...chunk);
    }
    return {
      pages,
      nn: Array.isArray(data.nn_payload?.nn) ? data.nn_payload.nn : []
    };
  } catch (e) {
    return { pages: [], nn: [], error: `Dream Offer JSON: ${e.message}` };
  }
}
async function fetchVacancySsr(nn, lang) {
  const res = await fetchText(`${BASE}/vacancy.html?nn=${nn}`, {
    headers: { ...headers(lang), Accept: "text/html" },
    proxy: false,
    timeoutMs: 2e4
  });
  if (!res.ok) return null;
  const m = res.text.match(/__VACANCY_SSR__\s*=\s*(\{[\s\S]*?\});?\s*<\/script>/);
  if (!m) return null;
  try {
    return ssrToJob(JSON.parse(m[1]));
  } catch {
    return null;
  }
}
async function mapPool(items, concurrency, fn) {
  const out = [];
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const idx = i++;
      const r = await fn(items[idx]);
      if (r != null) out.push(r);
    }
  }
  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  );
  return out;
}
async function fetchDreamOfferJobs(opts) {
  const limit = Math.min(Math.max(opts?.limit ?? 30, 1), 80);
  const lang = (opts?.lang || process.env.DREAMOFFER_LANG || "ru").trim() || "ru";
  const profession = opts?.profession?.trim() || process.env.DREAMOFFER_PROFESSION?.trim() || "Mobile";
  const workFormat = opts?.workFormat?.trim() || process.env.DREAMOFFER_WORK_FORMAT?.trim() || "remote";
  const scanExtra = Math.min(
    Math.max(
      opts?.scanExtra ?? (process.env.DREAMOFFER_SCAN_EXTRA ? Number(process.env.DREAMOFFER_SCAN_EXTRA) : 40),
      0
    ),
    120
  );
  const { pages, nn, error } = await fetchInitialDataset(lang);
  if (error && !pages.length) return { jobs: [], error };
  const filters = {
    profession: profession || void 0,
    workFormat: workFormat || void 0,
    keywords: opts?.keywords
  };
  const seen = /* @__PURE__ */ new Set();
  const jobs = [];
  for (const row of pages) {
    const job = rowToJob(row);
    if (!job || seen.has(job.id)) continue;
    if (!matchesFilters(job, filters)) continue;
    seen.add(job.id);
    jobs.push(job);
    if (jobs.length >= limit) break;
  }
  if (jobs.length < limit && scanExtra > 0 && nn.length) {
    const pageNns = new Set(
      pages.map((r) => Number(Array.isArray(r) ? r[0] : NaN)).filter(Number.isFinite)
    );
    const toScan = nn.filter((id) => !pageNns.has(id)).slice(0, scanExtra);
    const hydrated = await mapPool(toScan, 8, async (id) => {
      const job = await fetchVacancySsr(id, lang);
      if (!job || seen.has(job.id)) return null;
      if (!matchesFilters(job, filters)) return null;
      return job;
    });
    for (const job of hydrated) {
      if (seen.has(job.id)) continue;
      seen.add(job.id);
      jobs.push(job);
      if (jobs.length >= limit) break;
    }
  }
  jobs.sort((a, b) => b.date.localeCompare(a.date));
  return {
    jobs: jobs.slice(0, limit),
    ...error ? { error } : {}
  };
}

// src/module-entries/dreamoffer.ts
var meta = {
  id: "dreamoffer",
  version: "1.0.0",
  platforms: ["dreamoffer"]
};
async function fetchJobs(_ctx, opts) {
  return fetchDreamOfferJobs({
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    profession: typeof opts?.profession === "string" ? opts.profession : void 0,
    workFormat: typeof opts?.workFormat === "string" ? opts.workFormat : typeof opts?.work_format === "string" ? opts.work_format : void 0,
    keywords: Array.isArray(opts?.keywords) ? opts.keywords.filter((x) => typeof x === "string") : void 0,
    lang: typeof opts?.lang === "string" ? opts.lang : void 0,
    scanExtra: typeof opts?.scanExtra === "number" ? opts.scanExtra : void 0
  });
}
export {
  fetchJobs,
  meta
};
