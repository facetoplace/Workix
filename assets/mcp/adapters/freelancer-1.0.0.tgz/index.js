// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}

// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/freelancer.ts
var API = "https://www.freelancer.com/api";
function freelancerConfigured() {
  loadEnv();
  return Boolean(process.env.FREELANCER_OAUTH_TOKEN?.trim());
}
async function flnFetch(path, opts) {
  loadEnv();
  const token = process.env.FREELANCER_OAUTH_TOKEN?.trim();
  if (!token) return { error: "FREELANCER_OAUTH_TOKEN missing", status: 0 };
  try {
    const res = await fetch(`${API}${path}`, {
      method: opts?.method || "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        "Freelancer-OAuth-V1": token,
        Accept: "application/json"
      },
      body: opts?.body ? JSON.stringify(opts.body) : void 0
    });
    const text = await res.text();
    let json = {};
    try {
      json = JSON.parse(text);
    } catch {
      return {
        error: `Freelancer non-JSON HTTP ${res.status}: ${text.slice(0, 300)}`,
        status: res.status
      };
    }
    if (!res.ok) {
      return {
        error: json.message || `HTTP ${res.status}: ${text.slice(0, 300)}`,
        status: res.status
      };
    }
    return { data: json.result, status: res.status };
  } catch (e) {
    return {
      error: e instanceof Error ? e.message : String(e),
      status: 0
    };
  }
}
async function fetchFreelancerJobs(opts) {
  if (!freelancerConfigured()) {
    return { jobs: [], error: "FREELANCER_OAUTH_TOKEN missing (optional)" };
  }
  loadEnv();
  const q = opts?.query?.trim() || process.env.FREELANCER_SEARCH?.trim() || "VPN OR WireGuard OR Flutter OR mobile OR Android OR iOS";
  const limit = Math.min(Math.max(opts?.limit ?? 20, 1), 50);
  const params = new URLSearchParams({
    limit: String(limit),
    offset: "0",
    compact: "true",
    full_description: "true"
  });
  params.set("query", q);
  params.set("project_types[]", "fixed");
  params.append("project_types[]", "hourly");
  const path = `/projects/0.1/projects/active/?${params}`;
  const r = await flnFetch(path);
  if (r.error && !r.data?.projects) {
    const alt = new URLSearchParams({
      limit: String(limit),
      "or_search_query[]": q,
      compact: "true"
    });
    const r2 = await flnFetch(
      `/projects/0.1/projects/?${alt}`
    );
    if (r2.error && !r2.data?.projects) {
      return { jobs: [], error: r.error || r2.error };
    }
    return { jobs: mapProjects(r2.data?.projects || []), error: r2.error };
  }
  return { jobs: mapProjects(r.data?.projects || []), error: r.error };
}
function mapProjects(projects) {
  const jobs = [];
  for (const p of projects) {
    if (!p.id || !p.title) continue;
    const link = p.seo_url ? `https://www.freelancer.com/projects/${p.seo_url}` : `https://www.freelancer.com/projects/${p.id}`;
    const cur = p.currency?.code || "USD";
    const budget = p.budget?.minimum || p.budget?.maximum ? `${p.budget.minimum ?? "?"}-${p.budget.maximum ?? "?"} ${cur}` : void 0;
    const date = p.time_submitted ? new Date(p.time_submitted * 1e3).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
    jobs.push({
      id: jobId("freelancer_com", link),
      platform: "freelancer_com",
      kind: "gig",
      title: p.title,
      description: (p.preview_description || p.description || "").slice(0, 4e3),
      link,
      date,
      budget,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
      raw: p
    });
  }
  return jobs;
}
async function freelancerPlaceBid(opts) {
  if (!freelancerConfigured()) {
    return { ok: false, error: "FREELANCER_OAUTH_TOKEN missing" };
  }
  const r = await flnFetch(`/projects/0.1/bids/`, {
    method: "POST",
    body: {
      project_id: opts.projectId,
      amount: opts.amount,
      period: opts.period,
      description: opts.description,
      milestone_percentage: 100
    }
  });
  if (r.error) return { ok: false, error: r.error, raw: r.data };
  return { ok: true, raw: r.data };
}
function freelancerProjectId(job) {
  const raw = job.raw;
  return typeof raw?.id === "number" ? raw.id : void 0;
}

// src/module-entries/freelancer.ts
var meta = {
  id: "freelancer",
  version: "1.0.0",
  platforms: ["freelancer_com"],
  envKeys: ["FREELANCER_TOKEN", "FREELANCER_ACCESS_TOKEN"]
};
function configured() {
  return freelancerConfigured();
}
async function fetchJobs(_ctx, opts) {
  return fetchFreelancerJobs(opts);
}
async function placeBid(_ctx, opts) {
  return freelancerPlaceBid(opts);
}
function projectId(job) {
  return freelancerProjectId(job);
}
export {
  configured,
  fetchJobs,
  meta,
  placeBid,
  projectId
};
