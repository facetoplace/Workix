// src/adapters/workopia.ts
import { existsSync as existsSync3, mkdirSync as mkdirSync2, readFileSync as readFileSync3, writeFileSync } from "node:fs";
import { join as join3 } from "node:path";

// src/mcpClient.ts
var PROTOCOL_VERSION = "2025-06-18";
var CLIENT_INFO = { name: "workix-mcp", version: "0.3.2" };
function unwrap(body) {
  const trimmed = body.trim();
  if (!trimmed) throw new Error("empty response");
  if (trimmed.startsWith("{")) return JSON.parse(trimmed);
  const frames = trimmed.split(/\n\n+/).map(
    (chunk) => chunk.split("\n").filter((l) => l.startsWith("data:")).map((l) => l.slice(5).trim()).join("")
  ).filter((d) => d.startsWith("{"));
  if (!frames.length) throw new Error("no JSON frame in SSE response");
  return JSON.parse(frames[frames.length - 1]);
}
async function callMcpTool(opts) {
  const timeoutMs = opts.timeoutMs ?? 45e3;
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json, text/event-stream"
  };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const post = async (payload) => fetch(opts.url, {
    method: "POST",
    headers,
    body: JSON.stringify(payload),
    signal: controller.signal
  });
  try {
    const init = await post({
      jsonrpc: "2.0",
      id: 1,
      method: "initialize",
      params: {
        protocolVersion: PROTOCOL_VERSION,
        capabilities: {},
        clientInfo: CLIENT_INFO
      }
    });
    if (!init.ok) {
      return { error: `initialize HTTP ${init.status}` };
    }
    const session = init.headers.get("mcp-session-id");
    if (session) headers["mcp-session-id"] = session;
    await init.text();
    await post({ jsonrpc: "2.0", method: "notifications/initialized" }).catch(
      () => void 0
    );
    const res = await post({
      jsonrpc: "2.0",
      id: 2,
      method: "tools/call",
      params: { name: opts.tool, arguments: opts.args }
    });
    const body = await res.text();
    if (!res.ok) {
      return { error: `${opts.tool} HTTP ${res.status}: ${body.slice(0, 200)}` };
    }
    const env = unwrap(body);
    if (env.error) {
      return {
        error: `${opts.tool}: ${env.error.message || `rpc ${env.error.code}`}`
      };
    }
    const text = env.result?.content?.find((c) => c.text)?.text;
    let data;
    if (text) {
      try {
        data = JSON.parse(text);
      } catch {
      }
    }
    return {
      data,
      text,
      structured: env.result?.structuredContent,
      isError: env.result?.isError
    };
  } catch (e) {
    if (e instanceof Error && e.name === "AbortError") {
      return { error: `${opts.tool}: timed out after ${timeoutMs}ms` };
    }
    return { error: e instanceof Error ? e.message : String(e) };
  } finally {
    clearTimeout(timer);
  }
}

// src/profile.ts
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
function loadProfile() {
  const custom = process.env.WORKIX_PROFILE_PATH;
  const candidates = [
    custom,
    join(ROOT, "profile.md"),
    join(ROOT, "profile.example.md")
  ].filter(Boolean);
  for (const path of candidates) {
    if (existsSync(path)) {
      return readFileSync(path, "utf8");
    }
  }
  return "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u043D\u0435 \u0437\u0430\u0434\u0430\u043D. \u0421\u043E\u0437\u0434\u0430\u0439\u0442\u0435 mcp/profile.md \u043F\u043E \u043E\u0431\u0440\u0430\u0437\u0446\u0443 profile.example.md.";
}

// src/store.ts
import { createHash } from "node:crypto";

// src/db.ts
import { existsSync as existsSync2, mkdirSync, readFileSync as readFileSync2, renameSync } from "node:fs";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var emitWarning = process.emitWarning.bind(process);
process.emitWarning = ((warning, ...rest) => {
  const text = typeof warning === "string" ? warning : warning?.message || "";
  if (text.includes("SQLite is an experimental feature")) return;
  return emitWarning(warning, ...rest);
});
var { DatabaseSync } = await import("node:sqlite");
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function resolveDataDir() {
  const fromEnv = process.env.WORKIX_MCP_DATA?.trim();
  return fromEnv || join2(ROOT2, "data");
}
var handle = null;
var SCHEMA = `
CREATE TABLE IF NOT EXISTS jobs (
  id              TEXT PRIMARY KEY,
  platform        TEXT NOT NULL,
  kind            TEXT,
  title           TEXT NOT NULL,
  description     TEXT NOT NULL DEFAULT '',
  link            TEXT NOT NULL,
  date            TEXT NOT NULL,
  budget          TEXT,
  raw             TEXT,
  fetched_at      TEXT NOT NULL,
  seen_at         TEXT NOT NULL,
  shown_in_digest INTEGER NOT NULL DEFAULT 0,
  hub_share       TEXT
);
CREATE INDEX IF NOT EXISTS jobs_platform ON jobs(platform);
CREATE INDEX IF NOT EXISTS jobs_date ON jobs(date DESC);
CREATE INDEX IF NOT EXISTS jobs_link ON jobs(link);
CREATE INDEX IF NOT EXISTS jobs_seen ON jobs(seen_at DESC);

CREATE TABLE IF NOT EXISTS shown_digest (
  id TEXT PRIMARY KEY,
  at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS drafts (
  rowid_alias INTEGER PRIMARY KEY AUTOINCREMENT,
  job_id      TEXT NOT NULL,
  text        TEXT NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS drafts_job ON drafts(job_id, created_at DESC);

CREATE TABLE IF NOT EXISTS outreach (
  id      TEXT PRIMARY KEY,
  at      TEXT NOT NULL,
  status  TEXT NOT NULL,
  channel TEXT NOT NULL,
  contact TEXT NOT NULL,
  text    TEXT NOT NULL,
  project TEXT,
  url     TEXT,
  job_id  TEXT,
  note    TEXT
);
CREATE INDEX IF NOT EXISTS outreach_at ON outreach(at DESC);

CREATE TABLE IF NOT EXISTS checkpoints (
  id       TEXT PRIMARY KEY,
  at       TEXT NOT NULL,
  summary  TEXT NOT NULL,
  next     TEXT,
  surfaces TEXT,
  batch    TEXT,
  blocked  TEXT,
  note     TEXT
);
CREATE INDEX IF NOT EXISTS checkpoints_at ON checkpoints(at DESC);

CREATE TABLE IF NOT EXISTS hub_shares (
  id           TEXT PRIMARY KEY,
  at           TEXT NOT NULL,
  job_id       TEXT NOT NULL,
  platform     TEXT NOT NULL,
  title        TEXT NOT NULL,
  external_url TEXT NOT NULL,
  sid          TEXT NOT NULL,
  hub_url      TEXT NOT NULL,
  hub_id       TEXT,
  status       TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS hub_shares_at ON hub_shares(at DESC);
CREATE INDEX IF NOT EXISTS hub_shares_job ON hub_shares(job_id);

CREATE TABLE IF NOT EXISTS fetch_cache (
  key        TEXT PRIMARY KEY,
  source     TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  items      INTEGER NOT NULL DEFAULT 0,
  payload    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS fetch_cache_source ON fetch_cache(source);
CREATE INDEX IF NOT EXISTS fetch_cache_expires ON fetch_cache(expires_at);

CREATE TABLE IF NOT EXISTS meta (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS source_quality (
  source       TEXT PRIMARY KEY,
  searches     INTEGER NOT NULL DEFAULT 0,
  hits         INTEGER NOT NULL DEFAULT 0,
  errors       INTEGER NOT NULL DEFAULT 0,
  last_at      TEXT,
  last_query   TEXT,
  score        REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS source_quality_last ON source_quality(last_at);
`;
function db() {
  const dir = resolveDataDir();
  if (handle && handle.dir === dir) return handle.db;
  if (handle) handle.db.close();
  if (!existsSync2(dir)) mkdirSync(dir, { recursive: true });
  const conn = new DatabaseSync(join2(dir, "workix.db"));
  conn.exec("PRAGMA journal_mode = WAL");
  conn.exec("PRAGMA busy_timeout = 5000");
  conn.exec("PRAGMA foreign_keys = ON");
  conn.exec(SCHEMA);
  handle = { db: conn, dir };
  migrateStoreJson(conn, dir);
  return conn;
}
function nullable(v) {
  if (v === void 0 || v === null || v === "") return null;
  return typeof v === "string" ? v : JSON.stringify(v);
}
function migrateStoreJson(conn, dir) {
  const already = conn.prepare("SELECT v FROM meta WHERE k = 'migrated_store_json'").get();
  if (already) return;
  const legacy = join2(dir, "store.json");
  if (!existsSync2(legacy)) {
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run((/* @__PURE__ */ new Date()).toISOString());
    return;
  }
  let data;
  try {
    data = JSON.parse(readFileSync2(legacy, "utf8"));
  } catch {
    return;
  }
  const jobs = Object.values(
    data.jobs || {}
  );
  const insJob = conn.prepare(
    `INSERT OR REPLACE INTO jobs
     (id, platform, kind, title, description, link, date, budget, raw, fetched_at, seen_at, shown_in_digest, hub_share)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShown = conn.prepare(
    "INSERT OR IGNORE INTO shown_digest (id, at) VALUES (?, ?)"
  );
  const insDraft = conn.prepare(
    "INSERT INTO drafts (job_id, text, created_at) VALUES (?, ?, ?)"
  );
  const insOutreach = conn.prepare(
    `INSERT OR REPLACE INTO outreach (id, at, status, channel, contact, text, project, url, job_id, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insCheckpoint = conn.prepare(
    `INSERT OR REPLACE INTO checkpoints (id, at, summary, next, surfaces, batch, blocked, note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insShare = conn.prepare(
    `INSERT OR REPLACE INTO hub_shares (id, at, job_id, platform, title, external_url, sid, hub_url, hub_id, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const now = (/* @__PURE__ */ new Date()).toISOString();
  conn.exec("BEGIN");
  try {
    for (const j of jobs) {
      if (!j?.id || !j?.title || !j?.link) continue;
      insJob.run(
        String(j.id),
        String(j.platform || "unknown"),
        nullable(j.kind),
        String(j.title),
        String(j.description || ""),
        String(j.link),
        String(j.date || now),
        nullable(j.budget),
        j.raw === void 0 ? null : JSON.stringify(j.raw),
        String(j.fetchedAt || now),
        String(j.seenAt || now),
        j.shownInDigest ? 1 : 0,
        j.hubShare ? JSON.stringify(j.hubShare) : null
      );
    }
    for (const id of data.shownDigestIds || []) {
      insShown.run(String(id), now);
    }
    for (const d of data.drafts || []) {
      if (!d?.jobId) continue;
      insDraft.run(String(d.jobId), String(d.text || ""), String(d.createdAt || now));
    }
    for (const o of data.outreach || []) {
      if (!o?.id) continue;
      insOutreach.run(
        String(o.id),
        String(o.at || now),
        String(o.status || "draft"),
        String(o.channel || ""),
        String(o.contact || ""),
        String(o.text || ""),
        nullable(o.project),
        nullable(o.url),
        nullable(o.jobId),
        nullable(o.note)
      );
    }
    for (const c of data.checkpoints || []) {
      if (!c?.id) continue;
      insCheckpoint.run(
        String(c.id),
        String(c.at || now),
        String(c.summary || ""),
        nullable(c.next),
        c.surfaces ? JSON.stringify(c.surfaces) : null,
        nullable(c.batch),
        c.blocked ? JSON.stringify(c.blocked) : null,
        nullable(c.note)
      );
    }
    for (const h of data.hubShares || []) {
      if (!h?.id) continue;
      insShare.run(
        String(h.id),
        String(h.at || now),
        String(h.jobId || ""),
        String(h.platform || ""),
        String(h.title || ""),
        String(h.externalUrl || ""),
        String(h.sid || ""),
        String(h.hubUrl || ""),
        nullable(h.hubId),
        String(h.status || "created")
      );
    }
    conn.prepare("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_store_json', ?)").run(now);
    conn.exec("COMMIT");
  } catch (e) {
    conn.exec("ROLLBACK");
    throw e;
  }
  try {
    renameSync(legacy, `${legacy}.migrated`);
  } catch {
  }
  if (process.env.WORKIX_MCP_DEBUG) {
    console.error(`[workix] migrated ${jobs.length} jobs from store.json \u2192 workix.db`);
  }
}

// src/store.ts
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}
function dataDir() {
  db();
  return resolveDataDir();
}

// src/adapters/workopia.ts
var MCP_URL = "https://workopia.io/api/mcp-jobs";
var TOKEN_URL = "https://workopia.io/api/oauth/token";
var CALLBACK_PORT = Number(process.env.WORKOPIA_CALLBACK_PORT) || 51987;
var REDIRECT_URI = `http://127.0.0.1:${CALLBACK_PORT}/callback`;
function pickCards(payload) {
  if (!payload || typeof payload !== "object") return [];
  const p = payload;
  const buckets = [p.job_cards, p.jobs, p.results, p.data];
  for (const b of buckets) {
    if (!Array.isArray(b)) continue;
    return b.map((row) => {
      const r = row;
      return r.card && typeof r.card === "object" ? r.card : r;
    });
  }
  return [];
}
function companyOf(c) {
  if (typeof c.company === "string") return c.company;
  if (c.company && typeof c.company === "object") return c.company.name;
  return c.company_name;
}
function tokenPath() {
  return join3(dataDir(), "workopia-tokens.json");
}
function readTokens() {
  const p = tokenPath();
  if (!existsSync3(p)) return void 0;
  try {
    return JSON.parse(readFileSync3(p, "utf8"));
  } catch {
    return void 0;
  }
}
function writeTokens(t) {
  const dir = dataDir();
  mkdirSync2(dir, { recursive: true });
  writeFileSync(tokenPath(), JSON.stringify(t, null, 2), "utf8");
}
async function refresh(t) {
  if (!t.refresh_token) return void 0;
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: t.refresh_token,
      client_id: t.client_id
    })
  });
  if (!res.ok) return void 0;
  const j = await res.json();
  if (!j.access_token) return void 0;
  const next = {
    client_id: t.client_id,
    access_token: j.access_token,
    refresh_token: j.refresh_token || t.refresh_token,
    expires_at: j.expires_in ? Date.now() + j.expires_in * 1e3 : void 0
  };
  writeTokens(next);
  return next;
}
async function workopiaToken() {
  const fromEnv = process.env.WORKOPIA_TOKEN?.trim();
  if (fromEnv) return fromEnv;
  const stored = readTokens();
  if (!stored?.access_token) return void 0;
  if (stored.expires_at && stored.expires_at - Date.now() < 6e4) {
    const fresh = await refresh(stored);
    return fresh?.access_token;
  }
  return stored.access_token;
}
function workopiaConfigured() {
  return Boolean(process.env.WORKOPIA_TOKEN?.trim() || readTokens()?.access_token);
}
function resolveCity(explicit) {
  const direct = explicit?.trim() || process.env.WORKOPIA_CITY?.trim();
  if (direct) return direct;
  return cityFromProfile();
}
function cityFromProfile() {
  let text;
  try {
    text = loadProfile();
  } catch {
    return void 0;
  }
  const key = text.match(/^\s*(?:city|город|location|локация)\s*:\s*(.+)$/im);
  if (key?.[1]) return cleanCity(key[1]);
  const geo = text.match(/^\s*[-*]?\s*(?:Гео|Geo)\s*(?:\/[^:]*)?:\s*(.+)$/im);
  if (geo?.[1]) return cleanCity(geo[1]);
  return void 0;
}
function cleanCity(raw) {
  const first = raw.split(/[,/|]/)[0].replace(/[…\s]+$/g, "").trim();
  if (!first || /^[.…]+$/.test(first)) return void 0;
  if (/^[A-Z]{2}$/.test(first)) return void 0;
  return first;
}
async function fetchWorkopiaJobs(opts) {
  const token = await workopiaToken();
  if (!token) {
    return {
      jobs: [],
      error: "workopia: optional \u2014 not signed in. There is no API key to copy: the board uses OAuth with dynamic client registration. Run `npm run workopia:login` once (free account), or set WORKOPIA_TOKEN if you already hold a bearer token."
    };
  }
  const city = resolveCity(opts?.city);
  if (!city) {
    return {
      jobs: [],
      error: "workopia: optional \u2014 no city to search. Its job_tool requires one, and an empty value returns nothing rather than searching everywhere. Set WORKOPIA_CITY, or put `city: Berlin` (or `Remote`) in your mcp/profile.md \u2014 the adapter also reads the `\u0413\u0435\u043E / \u044F\u0437\u044B\u043A:` line."
    };
  }
  const jobTitle = (opts?.keywords || []).filter(Boolean).join(" ").trim() || "developer";
  const res = await callMcpTool({
    url: MCP_URL,
    tool: "job_tool",
    token,
    args: {
      action: "search",
      search_jobs: { job_title: jobTitle, city }
    }
  });
  if (res.error) return { jobs: [], error: `workopia: ${res.error}` };
  if (res.isError) {
    return { jobs: [], error: `workopia: ${(res.text || "rejected").slice(0, 300)}` };
  }
  const cards = pickCards(res.structured ?? res.data);
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 100);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const jobs = [];
  for (const c of cards.slice(0, limit)) {
    const link = c.apply_url || c.job_url || c.url;
    const title = c.title || c.job_title;
    if (!link || !title) continue;
    jobs.push({
      id: jobId("workopia", c.id || link),
      platform: "workopia",
      kind: "job",
      title,
      description: (c.description || c.snippet || "").replace(/\s+/g, " ").trim().slice(0, 4e3),
      link,
      date: c.posted_at || c.posted_date || now,
      budget: c.salary?.trim() || void 0,
      fetchedAt: now,
      raw: { company: companyOf(c), location: c.location, city }
    });
  }
  if (!jobs.length && cards.length) {
    return { jobs: [], error: "workopia: cards returned but none had a title and an apply URL" };
  }
  return { jobs };
}

// src/module-entries/workopia.ts
var meta = {
  id: "workopia",
  version: "1.0.0",
  platforms: ["workopia"],
  envKeys: ["WORKOPIA_TOKEN", "WORKOPIA_CITY", "WORKOPIA_CALLBACK_PORT"]
};
function configured() {
  return workopiaConfigured();
}
async function fetchJobs(_ctx, opts) {
  return fetchWorkopiaJobs({
    keywords: Array.isArray(opts?.keywords) ? opts.keywords.filter((k) => typeof k === "string") : void 0,
    limit: typeof opts?.limit === "number" ? opts.limit : void 0,
    city: typeof opts?.city === "string" ? opts.city : void 0
  });
}
export {
  configured,
  fetchJobs,
  meta
};
