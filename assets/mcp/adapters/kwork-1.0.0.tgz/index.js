// src/adapters/kwork.ts
import { createRequire } from "node:module";

// src/env.ts
import { config } from "dotenv";
import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
var ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
var REPO_ROOT = join(ROOT, "..");
var loaded = false;
function loadEnv() {
  if (loaded) return;
  const mcpEnv = join(ROOT, ".env");
  const rootEnv = join(REPO_ROOT, ".env");
  if (existsSync(rootEnv)) config({ path: rootEnv, override: false });
  if (existsSync(mcpEnv)) config({ path: mcpEnv, override: true });
  loaded = true;
}
function getProxyUrl() {
  loadEnv();
  const raw = process.env.PROXY_1 || process.env.KWORK_PROXY || process.env.WORKIX_HTTP_PROXY || "";
  const v = raw.trim();
  return v || void 0;
}

// src/proxyPool.ts
var CACHE_TTL_MS = 10 * 6e4;
var MAX_POOL = 40;
var cache = null;
var rr = 0;
function isUsableProxy(line) {
  return /^(socks5?|https?):\/\//i.test(line) || /^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(line);
}
function normalizeProxy(line) {
  const t = line.trim();
  if (/^\d{1,3}(\.\d{1,3}){3}:\d+$/.test(t)) return `socks5://${t}`;
  return t;
}
function parseProxyLines(text) {
  let body = text;
  const compact = text.replace(/\s/g, "");
  if (/^[A-Za-z0-9+/=]+$/.test(compact) && compact.length > 80) {
    try {
      body = Buffer.from(compact, "base64").toString("utf8");
    } catch {
    }
  }
  const out = [];
  for (const line of body.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    for (const part of t.split(/[,;|]+/).map((x) => x.trim())) {
      if (isUsableProxy(part)) out.push(normalizeProxy(part));
    }
  }
  return [...new Set(out)];
}
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
async function getProxyPool() {
  loadEnv();
  if (cache && Date.now() - cache.fetchedAt < CACHE_TTL_MS) {
    return cache.urls;
  }
  const raw = getProxyUrl();
  if (!raw) {
    cache = { urls: [], fetchedAt: Date.now() };
    return [];
  }
  if (/^socks/i.test(raw) && !/[\n,;|]/.test(raw)) {
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  if (/[\n,;|]/.test(raw)) {
    const inline = parseProxyLines(raw);
    const socks = inline.filter((u) => /^socks/i.test(u));
    const urls = (socks.length ? socks : inline).slice(0, MAX_POOL);
    cache = { urls, fetchedAt: Date.now() };
    return urls;
  }
  if (/^https?:\/\//i.test(raw)) {
    try {
      const res = await fetch(raw, {
        headers: { "User-Agent": "WorkixMCP/0.2 (+https://workix.co)" },
        signal: AbortSignal.timeout(2e4)
      });
      const text = await res.text();
      let urls = parseProxyLines(text);
      const socks = urls.filter((u) => /^socks/i.test(u));
      if (socks.length) urls = socks;
      if (urls.length > 0) {
        urls = shuffle(urls).slice(0, MAX_POOL);
        cache = { urls, fetchedAt: Date.now() };
        return urls;
      }
    } catch {
    }
    cache = { urls: [raw], fetchedAt: Date.now() };
    return cache.urls;
  }
  cache = { urls: [], fetchedAt: Date.now() };
  return [];
}
async function nextProxy() {
  const pool = await getProxyPool();
  if (!pool.length) return void 0;
  const url = pool[rr % pool.length];
  rr += 1;
  return url;
}

// src/store.ts
import { createHash } from "node:crypto";
import { dirname as dirname2, join as join2 } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
var ROOT2 = join2(dirname2(fileURLToPath2(import.meta.url)), "..");
function jobId(platform, link) {
  return createHash("sha1").update(`${platform}|${link}`).digest("hex").slice(0, 16);
}

// src/adapters/kwork.ts
var require2 = createRequire(import.meta.url);
function kworkConfigured() {
  return Boolean(
    process.env.KWORK_LOGIN && process.env.KWORK_PASSWORD && process.env.KWORK_PHONE4
  );
}
async function client() {
  loadEnv();
  if (!kworkConfigured()) {
    throw new Error(
      "Kwork \u043D\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D. \u0417\u0430\u0434\u0430\u0439\u0442\u0435 KWORK_LOGIN, KWORK_PASSWORD, KWORK_PHONE4 (\u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0435 4 \u0446\u0438\u0444\u0440\u044B \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0430)."
    );
  }
  const Kwork = require2("kwork-api");
  const login = process.env.KWORK_LOGIN;
  const password = process.env.KWORK_PASSWORD;
  const phone4 = process.env.KWORK_PHONE4;
  const proxy = process.env.KWORK_PROXY || await nextProxy() || void 0;
  return proxy ? new Kwork(login, password, phone4, proxy) : new Kwork(login, password, phone4);
}
function mapProject(p) {
  const idNum = p.id ?? p.project_id;
  const title = String(p.name || p.title || "").trim();
  const description = String(p.description || p.want_description || "").trim();
  if (!title) return null;
  const link = typeof p.url === "string" && p.url.startsWith("http") ? p.url : `https://kwork.ru/projects/${idNum}`;
  const budgetParts = [];
  if (p.price_limit != null) budgetParts.push(String(p.price_limit));
  if (p.possible_price_limit != null)
    budgetParts.push(`~${p.possible_price_limit}`);
  const dateRaw = p.date_confirm || p.date_create || p.date || Date.now();
  const date = typeof dateRaw === "number" ? new Date(dateRaw * (dateRaw < 1e12 ? 1e3 : 1)).toISOString() : new Date(String(dateRaw)).toISOString();
  return {
    id: jobId("kwork", link),
    platform: "kwork",
    kind: "gig",
    title,
    description,
    link,
    date,
    budget: budgetParts.length ? budgetParts.join(" / ") : void 0,
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    raw: p
  };
}
async function fetchKworkJobs() {
  if (!kworkConfigured()) {
    return {
      jobs: [],
      error: "Kwork credentials missing (optional for digest)"
    };
  }
  try {
    const kw = await client();
    const resp = await kw.getProjects();
    const list = resp?.response || resp || [];
    const jobs = list.map(mapProject).filter(Boolean);
    return { jobs };
  } catch (e) {
    return {
      jobs: [],
      error: e instanceof Error ? e.message : String(e)
    };
  }
}
async function kworkGetMe() {
  const kw = await client();
  return kw.getMe();
}

// src/module-entries/kwork.ts
var meta = {
  id: "kwork",
  version: "1.0.0",
  platforms: ["kwork"],
  envKeys: ["KWORK_LOGIN", "KWORK_PASSWORD", "KWORK_PHONE4", "KWORK_PROXY"]
};
function configured() {
  return kworkConfigured();
}
async function fetchJobs(_ctx) {
  return fetchKworkJobs();
}
async function getMe() {
  return kworkGetMe();
}
export {
  configured,
  fetchJobs,
  getMe,
  meta
};
